// Automated test runner that starts the Express server in-process, executes the test suite, and cleanly exits
const http = require('http');
const app = require('../server');

const PORT = 3001; // Use separate port for test isolation
process.env.PORT = PORT;

const server = app.listen(PORT, async () => {
  console.log(`[Test Runner] Test Server running on port ${PORT}`);
  process.env.BASE_URL = `http://localhost:${PORT}`;

  try {
    // Run the test suite by requiring or running the test file
    require('./test-api');
  } catch (err) {
    console.error('[Test Runner] Failure running test-api:', err);
    server.close(() => process.exit(1));
  }
});

