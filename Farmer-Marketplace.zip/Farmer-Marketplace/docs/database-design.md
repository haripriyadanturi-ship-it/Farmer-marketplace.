# FarmDirect Database Design Document
**Problem Statement ID:** HACK-P309  
**Database Engine:** SQLite (Embedded Relational Database)  
**Driver:** `better-sqlite3` (Synchronous, C++ binding with Write-Ahead Logging & Foreign Keys)  
**Storage File:** `database/farmer_marketplace.db`

---

## 1. Relational Architecture Overview

FarmDirect uses an embedded SQLite database engine configured for high durability, strict relational integrity, and rapid execution.

Key configurations enabled at initialization:
1. **`PRAGMA journal_mode = WAL;`**: Write-Ahead Logging provides high concurrent read performance while writes proceed without locking readers.
2. **`PRAGMA foreign_keys = ON;`**: Enforces referential integrity at the database engine level, rejecting orphan records.
3. **Prepared Statements**: Every query utilizes parameterized statements (`?`), eliminating SQL injection vulnerabilities.

---

## 2. Entity-Relationship Diagram (ERD)

```mermaid
erDiagram
    USERS ||--o{ PRODUCTS : "lists / owns"
    USERS ||--o{ ORDERS : "places as buyer"
    PRODUCTS ||--o{ ORDERS : "ordered in"

    USERS {
        INTEGER id PK "AUTOINCREMENT"
        TEXT name "Full Name / Organization"
        TEXT email "UNIQUE, NOT NULL, NOCASE"
        TEXT password_hash "bcrypt hashed string"
        TEXT role "CHECK (role IN ('farmer', 'buyer', 'admin'))"
        TEXT phone "Optional contact phone"
        TEXT location "Farm region or delivery address"
        DATETIME created_at "DEFAULT CURRENT_TIMESTAMP"
    }

    PRODUCTS {
        INTEGER id PK "AUTOINCREMENT"
        INTEGER farmer_id FK "REFERENCES users(id) ON DELETE CASCADE"
        TEXT name "Produce name"
        TEXT category "Produce category"
        REAL price "CHECK (price >= 0)"
        REAL quantity "CHECK (quantity >= 0)"
        TEXT unit "Measuring unit (kg, litre, quintal, etc.)"
        TEXT description "Harvest details"
        TEXT image_url "Direct photo URL"
        DATETIME created_at "DEFAULT CURRENT_TIMESTAMP"
    }

    ORDERS {
        INTEGER id PK "AUTOINCREMENT"
        INTEGER buyer_id FK "REFERENCES users(id) ON DELETE CASCADE"
        INTEGER product_id FK "REFERENCES products(id) ON DELETE RESTRICT"
        REAL quantity "CHECK (quantity > 0)"
        REAL total_price "CHECK (total_price >= 0)"
        TEXT status "CHECK (status IN ('Pending', 'Accepted', 'Shipped', 'Delivered', 'Cancelled'))"
        TEXT notes "Optional delivery instructions"
        DATETIME created_at "DEFAULT CURRENT_TIMESTAMP"
    }
```

---

## 3. Detailed Table Specifications

### A. Table: `users`
Stores authenticated entities interacting with the marketplace.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique identifier for each user |
| `name` | TEXT | NOT NULL | User's full name or farm enterprise name |
| `email` | TEXT | NOT NULL UNIQUE COLLATE NOCASE | Unique login email; case-insensitive |
| `password_hash`| TEXT | NOT NULL | 60-character bcrypt hash with 10 salt rounds |
| `role` | TEXT | NOT NULL CHECK(role IN ('farmer', 'buyer', 'admin')) | System authorization role |
| `phone` | TEXT | NULL | Mobile contact number for delivery coordination |
| `location` | TEXT | NULL | Geographic origin (farm region or buyer city) |
| `created_at` | DATETIME| DEFAULT CURRENT_TIMESTAMP | Account creation timestamp |

---

### B. Table: `products`
Stores agricultural harvest listings offered by verified farmers.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique product identifier |
| `farmer_id` | INTEGER | NOT NULL REFERENCES users(id) ON DELETE CASCADE | Foreign key linking produce to listing farmer |
| `name` | TEXT | NOT NULL | Descriptive produce name (e.g., 'Fresh Vine Tomatoes') |
| `category` | TEXT | NOT NULL | Category (Vegetables, Fruits, Grains, Dairy, Herbs) |
| `price` | REAL | NOT NULL CHECK(price >= 0) | Price per single unit in INR (₹) |
| `quantity` | REAL | NOT NULL CHECK(quantity >= 0) | Currently available stock quantity in inventory |
| `unit` | TEXT | NOT NULL DEFAULT 'kg' | Unit of measurement (kg, quintal, dozen, litre, pack) |
| `description` | TEXT | NULL | Farming methodology, freshness indicators, harvest date |
| `image_url` | TEXT | NULL | Produce photograph link |
| `created_at` | DATETIME| DEFAULT CURRENT_TIMESTAMP | Listing publication timestamp |

---

### C. Table: `orders`
Stores transactional purchase records between buyers and farmers.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Unique order identification number |
| `buyer_id` | INTEGER | NOT NULL REFERENCES users(id) ON DELETE CASCADE | Foreign key linking order to buyer |
| `product_id`| INTEGER | NOT NULL REFERENCES products(id) ON DELETE RESTRICT | Foreign key linking order to produce item |
| `quantity` | REAL | NOT NULL CHECK(quantity > 0) | Ordered quantity (must be greater than zero) |
| `total_price`| REAL | NOT NULL CHECK(total_price >= 0) | Backend-calculated amount (`quantity * unit_price`) |
| `status` | TEXT | NOT NULL DEFAULT 'Pending' | Current status (`Pending`, `Accepted`, `Shipped`, etc.) |
| `notes` | TEXT | NULL | Buyer notes for harvest handling or delivery instructions |
| `created_at` | DATETIME| DEFAULT CURRENT_TIMESTAMP | Order submission timestamp |

---

## 4. Performance Indexes

To support rapid filtering, search queries, and foreign key joins, dedicated indexes are created automatically during initialization:

```sql
CREATE INDEX IF NOT EXISTS idx_products_farmer ON products(farmer_id);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
CREATE INDEX IF NOT EXISTS idx_orders_buyer ON orders(buyer_id);
CREATE INDEX IF NOT EXISTS idx_orders_product ON orders(product_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
```

---

## 5. ACID Transactional Integrity Design

### The Stock Reduction Transaction
To guarantee that two buyers cannot purchase the same remaining stock concurrently (race condition), orders are processed inside an atomic SQLite transaction via `db.transaction(...)`:

```javascript
const executeOrderTransaction = db.transaction(() => {
  // 1. Lock and read fresh product stock
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);
  if (!product) throw new Error('Product not found.');

  // 2. Guard against insufficient stock
  if (product.quantity < orderQty) {
    throw new Error(`Insufficient stock. Requested: ${orderQty}, Available: ${product.quantity}`);
  }

  // 3. Compute immutable backend total
  const totalPrice = Number((product.price * orderQty).toFixed(2));
  const remainingStock = Number((product.quantity - orderQty).toFixed(2));

  // 4. Atomically reduce stock
  db.prepare('UPDATE products SET quantity = ? WHERE id = ?').run(remainingStock, productId);

  // 5. Insert order record
  const result = db.prepare(`
    INSERT INTO orders (buyer_id, product_id, quantity, total_price, status, notes)
    VALUES (?, ?, ?, ?, 'Pending', ?)
  `).run(buyerId, productId, orderQty, totalPrice, notes);

  return result.lastInsertRowid;
});
```

If any failure occurs (e.g., negative stock, constraint error, or process crash), the entire transaction rolls back cleanly, leaving stock quantities unmodified.

---

## 6. Auto-Seeding & Persistence

- The database file `farmer_marketplace.db` is saved persistently on disk.
- When `server.js` or `db.js` initializes on a fresh machine or clone, it checks `SELECT COUNT(*) FROM users`.
- If zero rows exist, it automatically invokes `seedData()`, loading 6 demo users, 8 realistic agricultural crops, and 4 sample orders across multiple stages.
- An administrative reset endpoint (`POST /api/admin/seed-reset`) is also provided so the team can cleanly refresh demo data between hackathon rounds.

