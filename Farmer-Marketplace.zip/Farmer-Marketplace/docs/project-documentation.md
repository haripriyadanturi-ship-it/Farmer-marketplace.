# FarmDirect: Direct Agricultural Marketplace
## College Hackathon Comprehensive Project Report & Technical Specification
**Problem Statement ID:** HACK-P309  
**Domain:** Backend Web Development & AgriTech Solutions  
**Submission Version:** 1.0.0 (Production-Ready Working Prototype)  

---

## 1. Project Title
**FarmDirect — Digital Marketplace Connecting Farmers Directly with Buyers**

---

## 2. Problem Statement ID
**HACK-P309** (Category: Backend Web Development & Full-Stack Systems)

---

## 3. Introduction
Agriculture serves as the backbone of our economy, sustaining millions of farmers and rural families. However, traditional agricultural distribution networks in India and across the developing world remain fragmented, inefficient, and heavily burdened by multi-layered intermediaries, commission agents (arhtiyas), and wholesale mandi cartels.

**FarmDirect** is an open, transparent, direct-to-consumer digital marketplace engineered to bridge the gap between agrarian producers and end buyers (households, restaurants, and retail grocers). By eliminating predatory middlemen, FarmDirect restores fair compensation to farmers while guaranteeing fresh, traceable harvest to consumers at competitive prices.

---

## 4. Problem Definition
The agricultural supply chain suffers from several chronic bottlenecks:
1. **Severe Price Disparity & Exploitation:** Farmers often receive as little as 20% to 30% of the final retail price paid by consumers, while intermediaries capture the vast majority of the profit margin.
2. **Post-Harvest Waste:** Inefficient distribution cycles result in produce traveling through multiple storage depots over 4–7 days, causing extensive spoilage and food waste before reaching the dinner table.
3. **Lack of Inventory & Price Transparency:** Smallholder farmers lack direct visibility into market demand and prevailing retail prices, leaving them vulnerable to distress selling at arbitrary gate prices.
4. **Counterfeit & Unregulated Quality:** Consumers have no visibility into the geographic origin, harvesting date, or cultivation practices of the produce they purchase.

---

## 5. Objectives
1. **Direct Farm-to-Fork Commerce:** Establish a seamless digital exchange allowing registered agricultural producers to list harvest inventory and receive direct orders from buyers.
2. **Transparent Price Discovery:** Empower farmers to set their own produce prices per unit (`kg`, `quintal`, `dozen`, `litre`, etc.) and receive 100% of sales proceeds without broker commissions.
3. **Transactional Inventory Integrity:** Prevent overselling and inventory race conditions through ACID-compliant database transactions that lock and deduct stock atomically.
4. **Role-Based Security:** Protect user accounts, private contact details, and financial transactions using cryptographic password hashing (bcrypt) and signed JSON Web Tokens (JWT).
5. **Frictionless Usability:** Provide a responsive, accessible web interface that functions effortlessly across desktop, tablet, and mobile browsers without requiring complex software installations.

---

## 6. Proposed Solution
FarmDirect implements a unified web platform integrating three core user experiences:
- **For Farmers:** A specialized dashboard to publish produce listings, specify stock quantities, attach crop descriptions and photographs, view incoming purchase requests, and update fulfillment milestones (`Pending` ➔ `Accepted` ➔ `Shipped` ➔ `Delivered`).
- **For Buyers:** A responsive marketplace featuring real-time search, category filters, live stock indicators, a dynamic order cost calculator, and end-to-end shipment tracking.
- **For Platform Administrators:** A diagnostic portal to supervise user registrations, inventory levels, marketplace revenue (GMV), and system health.

---

## 7. Technologies Used

| Layer | Technology | Version | Rationale & Selection Criteria |
|---|---|---|---|
| **Frontend UI** | HTML5, CSS3, JavaScript (ES6+) | Modern Standards | Ultra-fast load times, zero third-party framework overhead, 100% native browser compatibility. |
| **Styling & Theme** | Native CSS Custom Properties | CSS3 | Responsive flexbox and CSS grid layouts with an agricultural green, white, and earthy color palette. |
| **Backend Runtime** | Node.js | v24.x (LTS compatible) | Asynchronous, event-driven JavaScript runtime offering high throughput and low latency. |
| **Web Framework** | Express.js | v5.x | Minimalist, robust REST API framework with middleware pipelines and clean route separation. |
| **Database Engine** | SQLite (via `better-sqlite3`) | v3.4x embedded | Synchronous, embedded, zero-setup relational database with Write-Ahead Logging (WAL) and foreign keys. |
| **Authentication** | `jsonwebtoken` & `bcryptjs` | v9.x & v3.x | Industry-standard password hashing with 10 salt rounds and tamper-resistant cryptographic Bearer tokens. |
| **API Testing** | Custom In-Memory Test Runner & Postman | v2.1 Collection | 100% automated test coverage with 32 assertions and exportable Postman suite. |
| **Version Control** | Git & GitHub | Git 2.x | Distributed version control with structured commits, `.gitignore`, and `.env.example`. |

---

## 8. System Architecture

```mermaid
flowchart TD
    subgraph Client ["Client Layer (Browser)"]
        UI["Vanilla JS Single Page App\n(HTML5 / CSS3 / ES6)"]
        LocalStorage["Client Storage\n(JWT & User Session)"]
    end

    subgraph Server ["Backend Layer (Node.js & Express)"]
        Router["Express Router Pipeline\n(/api/auth, /api/products, /api/orders, /api/admin)"]
        AuthMiddleware["JWT Verification & RBAC Middleware\n(authenticateToken, authorizeRoles)"]
        BusinessLogic["Business Logic Controllers\n(Price Calc, Ownership Check, Status Guards)"]
    end

    subgraph Database ["Persistence Layer (SQLite)"]
        SQLiteEngine["SQLite Embedded DB Engine\n(PRAGMA journal_mode=WAL;\nPRAGMA foreign_keys=ON;)"]
        TxEngine["Atomic Transaction Engine\n(Stock Reduction & Order Insert)"]
        Tables["Relational Tables\n(users, products, orders)"]
    end

    UI -->|"HTTP REST API Calls\n(JSON + Bearer Token)"| Router
    LocalStorage <-->|"Persist / Retrieve Session"| UI
    Router --> AuthMiddleware
    AuthMiddleware --> BusinessLogic
    BusinessLogic -->|"Parameterized Prepared Statements"| SQLiteEngine
    BusinessLogic -->|"Atomic db.transaction()"| TxEngine
    TxEngine --> Tables
    SQLiteEngine --> Tables
```

---

## 9. Frontend Modules
The frontend is structured as a responsive Single-Page Application (SPA) driven by `public/app.js` and styled via `public/style.css`:
1. **Navigation & Identity Header:** Displays the FarmDirect brand logo, navigation links, role-specific views (Farmer Dashboard vs. My Orders vs. Admin Portal), and user session chips.
2. **Hero & Discovery Section:** Features value propositions, impact statistics (0% Middlemen, 100% Direct), category shortcuts, and one-click demo credentials for judges.
3. **Produce Marketplace Grid:** Displays real-time produce cards containing product image, category pill, farm origin, stock badges (`In Stock`, `Low Stock`, `Out of Stock`), and "Order Now" triggers.
4. **Live Order Modal:** Automatically calculates total price dynamically based on user input, validates requested quantity against available stock, and transmits orders to the backend.
5. **Farmer Portal:** Provides KPI summary cards (Total Products, Stock Units, Pending Orders, Revenue), an interactive inventory table with Edit/Delete controls, and an order fulfillment console.
6. **Buyer Orders Console:** Renders placed orders with visual step-by-step progress tracking bars (`Pending` ➔ `Accepted` ➔ `Shipped` ➔ `Delivered`).
7. **Toast Notification System:** Asynchronous non-blocking floating alerts for feedback on actions, errors, and system events.

---

## 10. Backend Modules
1. **Server Initialization (`server.js`):** Configures middleware (`cors`, `express.json`), request duration logging, static file serving, API routing, and graceful SIGINT database disconnection.
2. **Authentication Route (`routes/auth.js`):**
   - Validates user input (email regex, password length >= 6, permitted roles).
   - Prevents duplicate email registrations with HTTP 409 Conflict.
   - Hashes passwords using bcrypt with 10 salt rounds.
   - Signs and verifies JWT tokens containing `id`, `email`, `role`, and `name`.
3. **Security Middleware (`middleware/authMiddleware.js`):**
   - Extracts Bearer token from the `Authorization` header.
   - Validates signature using `JWT_SECRET`.
   - Enforces Role-Based Access Control (`authorizeRoles('farmer', 'admin')`).
4. **Products Route (`routes/products.js`):**
   - Handles produce retrieval with parameterized filters (`?q=`, `?category=`, `?farmer_id=`, `?in_stock=`).
   - Enforces ownership guards: farmers can only modify or delete produce items they personally created.
   - Prevents hard deletion of products tied to historical orders to maintain financial audit integrity.
5. **Orders Route (`routes/orders.js`):**
   - Enforces transactional order placement via `db.transaction(...)`.
   - Calculates immutable total price on the backend (`price * quantity`).
   - Atomically deducts inventory stock and rejects excessive requests.
   - Provides role-aware order retrieval (buyers see purchases, farmers see sales).
   - Manages status transitions and restores stock upon cancellation.
6. **Admin Route (`routes/admin.js`):**
   - Aggregates platform-wide metrics (Gross Merchandise Value, order breakdown, low stock).
   - Provides a safe demo database re-seeding mechanism (`POST /api/admin/seed-reset`).

---

## 11. Database Design
- **Engine:** SQLite with Write-Ahead Logging (`WAL`) mode enabled.
- **Foreign Keys:** Enabled via `PRAGMA foreign_keys = ON;`.
- **Relational Tables:**
  - `users`: `id`, `name`, `email`, `password_hash`, `role`, `phone`, `location`, `created_at`.
  - `products`: `id`, `farmer_id` (FK), `name`, `category`, `price`, `quantity`, `unit`, `description`, `image_url`, `created_at`.
  - `orders`: `id`, `buyer_id` (FK), `product_id` (FK), `quantity`, `total_price`, `status`, `notes`, `created_at`.
- **Indexes:** Created on `products(farmer_id)`, `products(category)`, `orders(buyer_id)`, `orders(product_id)`, and `orders(status)`.

---

## 12. Complete API Endpoints Reference

| Endpoint | Method | Role Required | Description |
|---|---|---|---|
| `/api/health` | GET | Public | Server uptime, database status, problem ID (`HACK-P309`) |
| `/api/auth/register` | POST | Public | Registers a new Farmer or Buyer account |
| `/api/auth/login` | POST | Public | Authenticates credentials and returns JWT token |
| `/api/auth/me` | GET | Authenticated | Retrieves current authenticated profile |
| `/api/products` | GET | Public | Lists products with search, category & stock filters |
| `/api/products/:id` | GET | Public | Retrieves specific product and farm origin details |
| `/api/products` | POST | Farmer / Admin | Adds a new agricultural produce listing |
| `/api/products/:id` | PUT | Farmer (Owner) | Updates price, stock, or description of a listing |
| `/api/products/:id` | DELETE | Farmer (Owner) | Removes a produce listing (guarded against active orders)|
| `/api/orders` | POST | Buyer / Admin | Places order with atomic backend stock deduction |
| `/api/orders/my` | GET | Authenticated | Role-aware order history (Buyer purchases / Farmer sales) |
| `/api/orders/:id/status`| PATCH | Farmer (Owner) | Transitions order status (`Accepted`, `Shipped`, etc.) |
| `/api/admin/stats` | GET | Admin | System-wide statistics and Gross Merchandise Value |
| `/api/admin/users` | GET | Admin | Lists all registered accounts (passwords omitted) |
| `/api/admin/seed-reset` | POST | Admin / Passkey| Cleanly resets database to demo seed state |

---

## 13. Main Features
1. **Zero-Middleman Direct Trade:** Eliminates third-party broker markups, transferring 100% of the sale value directly to the grower.
2. **Backend Price Recalculation:** Client-side prices are never trusted blindly; the server computes `unit_price * quantity` from SQLite directly.
3. **Transactional Concurrency Safety:** Stock is checked and decremented within an atomic transaction, preventing overselling.
4. **Order Status Progression:** 4-stage visual order tracker (`Pending` ➔ `Accepted` ➔ `Shipped` ➔ `Delivered`) providing transparency to both parties.
5. **Automatic Inventory Restoration:** If an order is marked `Cancelled`, inventory stock is automatically returned to the farmer's listing.
6. **Demo Mode for Evaluators:** One-click demo logins pre-configured for a Farmer (Ramesh), Buyer (Priya), and Administrator to simplify hackathon judging.

---

## 14. Functional Workflow (End-to-End Walkthrough)
1. **Farmer Onboarding & Login:** Farmer Ramesh Patel logs into the platform and opens the Farmer Dashboard.
2. **Listing Produce:** Farmer lists `Fresh Vine Tomatoes` at `₹35.00/kg` with initial stock of `200 kg`.
3. **Database Persistence:** The listing is saved into the SQLite `products` table.
4. **Buyer Discovery:** Buyer Priya Verma logs in, searches for `Tomatoes`, and selects the newly listed crop.
5. **Ordering & Stock Check:** Priya places an order for `10 kg`.
6. **Atomic Transaction:** The backend verifies `200 >= 10`, calculates the total (`₹350.00`), decrements available stock from `200` to `190 kg`, and generates Order `#ORD-1005`.
7. **Order Notification & Acceptance:** Farmer Ramesh sees the incoming order on his dashboard and updates the status to `Accepted`, then to `Shipped`.
8. **Buyer Real-Time Tracking:** Priya opens her order tracking screen and sees the completed progress steps updated in real time.

---

## 15. Testing Performed
An automated test suite (`tests/test-api.js`) was engineered to test all 32 core business and security requirements:
- **Server Health:** Verified HTTP 200 and healthy SQLite connection.
- **Registration & Validation:** Confirmed user creation, role assignment, and omission of password hashes in responses.
- **Duplicate Email Rejection:** Confirmed HTTP 409 Conflict when attempting to register an existing email.
- **Authentication Security:** Verified HTTP 401 on incorrect password and successful JWT issuance on valid login.
- **Discovery & Query Filtering:** Verified search queries (`?q=Tomatoes`) and category filtering (`?category=Fruits`).
- **Role-Based Authorization:** Confirmed buyers cannot post produce (HTTP 403 Forbidden).
- **Ownership Guards:** Confirmed farmers cannot edit produce listed by other farmers.
- **Transactional Stock Deduction:** Verified stock decreases exactly by ordered amount (100 ➔ 90 kg).
- **Insufficient Stock Guard:** Verified orders exceeding current stock are rejected with HTTP 400.
- **Status Lifecycle:** Verified transitions (`Pending` ➔ `Accepted` ➔ `Shipped`).
- **Audit Preservation:** Verified products with active orders cannot be hard-deleted.

**Test Summary:** 32 executed | 32 passed | 0 failed (100% pass rate).

---

## 16. Advantages
1. **Economic Empowerment:** Enhances rural income by removing broker cartels.
2. **Freshness Guarantee:** Eliminates intermediate warehousing delays, delivering fresher harvest to buyers.
3. **Zero Configuration Deployment:** Runs locally on SQLite without requiring complex external database server setups like PostgreSQL or MySQL.
4. **High Security Standards:** Uses salted bcrypt password hashing, JWT authorization, and parameterized SQL statements that prevent SQL injection.
5. **Lightweight & Fast:** Built entirely with vanilla HTML5, CSS3, and modern JavaScript, yielding sub-100ms API response times.

---

## 17. Limitations
1. **Integrated Payment Gateway:** The current prototype simulates payments on delivery/direct settlement rather than integrating third-party gateways (e.g., Razorpay/Stripe), which require paid merchant credentials.
2. **Physical Logistics Routing:** Order tracking relies on status updates marked by the farmer rather than live GPS vehicle telematics.
3. **Single Region Deployment:** The current prototype is optimized for regional hub operations rather than multi-currency cross-border trade.

---

## 18. Future Enhancements
1. **SMS & WhatsApp Dispatch Alerts:** Integrate Twilio or WhatsApp Business API to send notifications directly to farmers' basic mobile phones.
2. **Multilingual Localization:** Add regional language support (Hindi, Marathi, Punjabi, Gujarati, Tamil) for non-English literate farmers.
3. **AI Crop Price Predictor:** Implement a machine learning model analyzing regional APMC market rates to advise farmers on optimal selling prices.
4. **Cold Chain Logistics Integration:** Partner with third-party local delivery fleets for automated order dispatch and route optimization.

---

## 19. Conclusion
FarmDirect successfully addresses Problem Statement **HACK-P309** by delivering a fully functional, resilient, and beautifully designed agricultural marketplace. Through careful architectural planning—combining Express REST APIs, atomic SQLite transactions, JWT authentication, and a responsive frontend—the project proves that digital technology can simplify agricultural commerce, eliminate exploitation, and build a sustainable, direct connection between farmers and consumers.

