# FarmDirect Demonstration Video Script (2–3 Minutes)
**Hackathon Problem Statement ID:** HACK-P309  
**Project Name:** FarmDirect — Direct Agricultural Marketplace  
**Target Duration:** 2 minutes 45 seconds  
**Resolution / Setting:** 1080p 60fps fullscreen capture at `http://localhost:3000`

---

## Storyboard Overview & Timeline

| Scene | Duration | Topic | Core Visual on Screen |
|---|---|---|---|
| **Scene 1** | 0:00 – 0:25 | Project Intro & Problem Definition | Homepage hero section & direct pricing advantage |
| **Scene 2** | 0:25 – 0:50 | Farmer Experience & Adding Produce | Farmer login, inventory dashboard & adding fresh tomatoes |
| **Scene 3** | 0:50 – 1:20 | Buyer Experience & Placing Order | Marketplace search, filter, real-time total calculator & order placement |
| **Scene 4** | 1:20 – 1:55 | Order Lifecycle & Status Progression | Farmer accepts & marks order Shipped; Buyer tracks real-time progress |
| **Scene 5** | 1:55 – 2:25 | Tech Stack & Architectural Highlights | SQLite transaction, JWT auth, Postman collection & 100% test suite run |
| **Scene 6** | 2:25 – 2:45 | Conclusion & Hackathon Submission | Closing recap with team contribution and GitHub repository |

---

## Detailed Script & On-Screen Actions

### Scene 1: Introduction & The Agricultural Problem (0:00 – 0:25)
- **On Screen:**
  - Browser opens to `http://localhost:3000`.
  - Cursor smoothly scrolls past the top banner showing `Problem Statement ID: HACK-P309`.
  - Shows the Hero title: *"Empowering Farmers, Nourishing Communities"* and key metrics (0% Middlemen Commission, 100% Direct Farm Origin).
- **Voiceover / Narration:**
  > *"Hello, judges and evaluators! Welcome to FarmDirect, developed for Problem Statement HACK-P309.  
  > In conventional agricultural supply chains, smallholder farmers lose up to 40% of their produce value to multi-tiered intermediaries and brokers, while buyers pay inflated prices for stale produce.  
  > FarmDirect solves this through a digital marketplace connecting agricultural producers directly with buyers—providing fair pricing, direct listings, and transactional integrity."*

---

### Scene 2: Farmer Registration, Login & Produce Listing (0:25 – 0:50)
- **On Screen:**
  - Click the **"⚡ Quick Demo Logins"** button or click **"Log In"**.
  - Click **"👨‍🌾 Demo Farmer"** (Logs in as Ramesh Patel).
  - Browser automatically transitions to the **Farmer Dashboard**.
  - Show KPI cards: Total Products, Available Stock, Incoming Orders, and Estimated Revenue.
  - Click **"➕ Add New Produce Listing"**.
  - Fill in modal:
    - Produce Name: `Fresh Vine Tomatoes (Desi)`
    - Category: `Vegetables`
    - Price: `₹35.00` per `kg`
    - Stock Quantity: `200`
    - Click preset chip for `🍅 Tomatoes`.
  - Click **"Save Produce Listing"**. Toast appears: *"Produce added to marketplace catalog!"*
- **Voiceover / Narration:**
  > *"Let's begin with the Farmer's workflow. Ramesh Patel logs in and arrives at his Farmer Dashboard, displaying his active inventory and incoming orders.  
  > With just a few clicks, he adds a fresh harvest of desi vine tomatoes at ₹35 per kg with 200 kg in stock. The record is instantly committed to our SQLite database."*

---

### Scene 3: Buyer Discovery & Placing a Transactional Order (0:50 – 1:20)
- **On Screen:**
  - Click **"Log Out"**, then click **"🛒 Demo Buyer"** (Logs in as Priya Verma).
  - Navigate to **"Marketplace"**.
  - In the search bar, type `Tomatoes` (live search instantly filters results).
  - Click category pill **"🥦 Vegetables"**.
  - Click **"🛒 Order Now"** on the freshly added tomato card.
  - The Order Modal opens:
    - Demonstrates stepper button increasing quantity to `10 kg`.
    - Live calculation dynamically shows `10 kg × ₹35.00 = ₹350.00`.
    - Type note: *"Deliver before 11 AM"*.
  - Click **"Confirm & Place Order"**.
  - Toast notification appears: *"Order placed successfully!"*
- **Voiceover / Narration:**
  > *"Now, Priya Verma, an urban buyer, logs in and explores the Produce Marketplace.  
  > She searches for fresh tomatoes, selects 10 kg, and reviews the calculated total of ₹350.  
  > When she confirms, an atomic SQLite transaction executes on our Express backend: validating available stock, computing the price server-side, reducing available inventory from 200 to 190 kg, and creating the order record."*

---

### Scene 4: Farmer Order Fulfillment & Real-Time Tracking (1:20 – 1:55)
- **On Screen:**
  - Switch back to the Farmer account via **"⚡ Quick Demo Logins ➔ 👨‍🌾 Farmer"**.
  - On the Farmer Dashboard, click the **"📥 Orders Received"** tab.
  - Show the newly arrived order with Order ID, Buyer contact (`Priya Verma`), quantity `10 kg`, and total amount `₹350.00`.
  - In the status dropdown, change status from `Pending` to **`Accepted`**, then to **`Shipped`**.
  - Toast confirms status update.
  - Switch back to Buyer account and navigate to **"📦 My Orders"**.
  - Display the Order Card showing the visual tracking bar with completed checkmarks across `Pending ➔ Accepted ➔ Shipped`.
- **Voiceover / Narration:**
  > *"Back on the Farmer portal, Ramesh sees the incoming order. He reviews Priya's delivery note and accepts the order, then marks it as Shipped.  
  > Switching back to Priya's 'My Orders' screen, she immediately sees the updated tracking bar reflecting the dispatched harvest in real-time."*

---

### Scene 5: Architectural Highlights & Automated Test Suite (1:55 – 2:25)
- **On Screen:**
  - Switch to VS Code terminal or command prompt.
  - Run `npm test` (`node tests/test-api.js`).
  - Terminal displays:
    ```
    🌾 FarmDirect (HACK-P309) Automated Test Suite
    1️⃣ Health Check & SQLite Connection -> PASS
    2️⃣ User Registration & Validation -> PASS
    3️⃣ Duplicate Email Prevention -> PASS
    4️⃣ Authentication & Credentials -> PASS
    ...
    📊 TEST RESULTS: Total: 32 | Passed: 32 | Failed: 0
    🎉 ALL HACKATHON BACKEND & API TESTS PASSED WITH 100% SUCCESS!
    ```
  - Briefly open `docs/postman-collection.json` in Postman showing organized folders for Auth, Products, Orders, and Admin endpoints.
- **Voiceover / Narration:**
  > *"Under the hood, FarmDirect is built with Node.js and Express, SQLite with Write-Ahead Logging, bcrypt password hashing, and JWT authorization.  
  > Every endpoint is guarded against unauthorized access. Our automated test suite verifies 32 separate test assertions—including duplicate email prevention, stock deduction transactions, and role enforcement—with a 100% pass rate."*

---

### Scene 6: Conclusion & Submission Wrap-Up (2:25 – 2:45)
- **On Screen:**
  - Show the browser back at the Homepage footer highlighting `HACK-P309` and the team contribution overview.
  - Show the Git repository ready for evaluation.
- **Voiceover / Narration:**
  > *"To conclude, FarmDirect delivers a complete, secure, and production-ready prototype that connects farmers directly with buyers, guarantees transparent compensation, and eliminates agricultural middlemen.  
  > Thank you for your time and consideration!"*

