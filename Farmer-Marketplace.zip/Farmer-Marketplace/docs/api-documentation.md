# FarmDirect REST API Documentation
**Hackathon Problem Statement ID:** HACK-P309  
**Platform Base URL:** `http://localhost:3000`  
**Authentication Type:** JSON Web Token (JWT) Bearer Authentication (`Authorization: Bearer <token>`)

---

## 1. Authentication Endpoints

### Register User
- **Method:** `POST`
- **Path:** `/api/auth/register`
- **Access:** Public
- **Description:** Registers a new Farmer or Buyer account. Passwords are automatically hashed with bcrypt (salt rounds = 10).
- **Request Body:**
```json
{
  "name": "Ramesh Patel",
  "email": "ramesh.farmer@farmdirect.com",
  "password": "Farmer@123",
  "role": "farmer",
  "phone": "+91 98765 43210",
  "location": "Anand, Gujarat"
}
```
- **Responses:**
  - `201 Created`: User successfully registered; returns JWT token and sanitized user profile (password hash omitted).
  - `400 Bad Request`: Missing mandatory fields, invalid email format, password under 6 characters, or invalid role.
  - `409 Conflict`: An account with this email address already exists.

---

### User Login
- **Method:** `POST`
- **Path:** `/api/auth/login`
- **Access:** Public
- **Description:** Authenticates user credentials and returns a signed JWT token valid for 7 days.
- **Request Body:**
```json
{
  "email": "priya.buyer@farmdirect.com",
  "password": "Buyer@123"
}
```
- **Responses:**
  - `200 OK`: Successful authentication; returns user object and JWT token.
  - `400 Bad Request`: Email or password omitted.
  - `401 Unauthorized`: Invalid credentials.

---

### Get Current User Profile
- **Method:** `GET`
- **Path:** `/api/auth/me`
- **Access:** Authenticated (Any role)
- **Header:** `Authorization: Bearer <token>`
- **Response:**
  - `200 OK`: Returns authenticated user's profile details.

---

## 2. Product Endpoints

### List Marketplace Produce
- **Method:** `GET`
- **Path:** `/api/products`
- **Access:** Public
- **Query Parameters:**
  - `q` (string): Search keyword against product name and description.
  - `category` (string): Filter by produce category (e.g., `Vegetables`, `Fruits`, `Grains & Cereals`).
  - `farmer_id` (integer): Filter produce listed by a specific farmer.
  - `min_price` / `max_price` (numeric): Filter by price range.
  - `in_stock` (boolean): `true` to return only produce with stock quantity > 0.
- **Response:**
  - `200 OK`: Array of products including joined farmer contact details.

---

### Get Single Product by ID
- **Method:** `GET`
- **Path:** `/api/products/:id`
- **Access:** Public
- **Response:**
  - `200 OK`: Full product record and farm origin information.
  - `404 Not Found`: Product ID does not exist.

---

### Add Produce Listing
- **Method:** `POST`
- **Path:** `/api/products`
- **Access:** Protected (`farmer` or `admin` role)
- **Header:** `Authorization: Bearer <token>`
- **Request Body:**
```json
{
  "name": "Fresh Vine Tomatoes (Desi)",
  "category": "Vegetables",
  "price": 35.0,
  "quantity": 250,
  "unit": "kg",
  "description": "Naturally ripened desi tomatoes harvested this morning.",
  "image_url": "https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600"
}
```
- **Responses:**
  - `201 Created`: Produce listed in marketplace.
  - `400 Bad Request`: Validation failure (negative price or quantity).
  - `403 Forbidden`: User role is not `farmer` or `admin`.

---

### Update Produce Listing
- **Method:** `PUT`
- **Path:** `/api/products/:id`
- **Access:** Protected (Product Owner or `admin`)
- **Header:** `Authorization: Bearer <token>`
- **Request Body:** Partial or complete fields (`price`, `quantity`, `description`, etc.)
- **Responses:**
  - `200 OK`: Listing updated in database.
  - `403 Forbidden`: Farmer attempted to modify a product belonging to another farm.
  - `404 Not Found`: Product does not exist.

---

### Delete Produce Listing
- **Method:** `DELETE`
- **Path:** `/api/products/:id`
- **Access:** Protected (Product Owner or `admin`)
- **Responses:**
  - `200 OK`: Listing removed.
  - `400 Bad Request`: Blocked if active order history exists (to preserve transactional audit trails).
  - `403 Forbidden`: Farmer attempted to delete another farmer's product.

---

## 3. Order Endpoints

### Place Produce Order
- **Method:** `POST`
- **Path:** `/api/orders`
- **Access:** Protected (`buyer` or `admin` role)
- **Header:** `Authorization: Bearer <token>`
- **Transaction Guarantee:** Atomic SQLite transaction locks the product row, validates available stock, calculates total price (`unit_price * quantity`), deducts stock, and creates order record.
- **Request Body:**
```json
{
  "product_id": 1,
  "quantity": 5,
  "notes": "Please pack in breathable crates."
}
```
- **Responses:**
  - `201 Created`: Order placed and stock deducted.
  - `400 Bad Request`: Quantity exceeds available stock, invalid ID, or quantity <= 0.
  - `404 Not Found`: Product not found.

---

### Get My Orders
- **Method:** `GET`
- **Path:** `/api/orders/my`
- **Access:** Authenticated (Role-aware)
  - `buyer`: Returns purchases placed by this buyer.
  - `farmer`: Returns incoming purchase orders for this farmer's produce.
  - `admin`: Returns all orders across the entire marketplace.
- **Header:** `Authorization: Bearer <token>`
- **Response:**
  - `200 OK`: Order collection with joined product and counterparty contact info.

---

### Update Order Status
- **Method:** `PATCH`
- **Path:** `/api/orders/:id/status`
- **Access:** Protected (Farmer of the product, or `admin`)
- **Header:** `Authorization: Bearer <token>`
- **Permitted Statuses:** `Pending`, `Accepted`, `Shipped`, `Delivered`, `Cancelled`
- **Stock Restoration:** If status is changed to `Cancelled`, the deducted stock is automatically restored to the product inventory.
- **Request Body:**
```json
{
  "status": "Accepted"
}
```
- **Responses:**
  - `200 OK`: Status updated.
  - `400 Bad Request`: Invalid status string.
  - `403 Forbidden`: Farmer does not own the ordered produce.

---

## 4. Admin & Health Endpoints

### System Health
- **Method:** `GET`
- **Path:** `/api/health`
- **Access:** Public
- **Response:** Health status, database ping, uptime, and hackathon problem statement ID (`HACK-P309`).

---

### Platform Metrics
- **Method:** `GET`
- **Path:** `/api/admin/stats`
- **Access:** Protected (`admin` role)
- **Response:** Total farmers, buyers, listings, gross merchandise value (GMV), order status breakdown, low-stock warnings.

---

### Demo Seed Reset
- **Method:** `POST`
- **Path:** `/api/admin/seed-reset`
- **Access:** Protected (Admin Token OR Passkey: `hackathon-p309`)
- **Request Body:** `{ "passkey": "hackathon-p309" }`
- **Response:** `200 OK` when the SQLite database is re-initialized with fresh demo data.

