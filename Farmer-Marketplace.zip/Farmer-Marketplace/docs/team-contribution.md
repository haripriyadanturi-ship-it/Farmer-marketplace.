# Four-Member Team Contribution & Responsibilities
**Project Title:** FarmDirect — Agricultural Marketplace  
**Problem Statement ID:** HACK-P309  
**Team Structure:** Four Students from the Same Section  

---

## Executive Summary & Division of Labor

To ensure every team member has a substantial, measurable, and defendable role during the hackathon evaluation, the project is structured across four primary engineering domains:

```
┌────────────────────────────────────────────────────────────────────────┐
│                   HACKATHON TEAM DIVISION (HACK-P309)                 │
├───────────────────┬───────────────────┬────────────────────────────────┤
│ Member & Role     │ Domain Focus      │ Key Deliverables & Files       │
├───────────────────┼───────────────────┼────────────────────────────────┤
│ Member 1          │ Frontend & UI/UX  │ • public/index.html            │
│ Frontend Engineer │ Interaction Design│ • public/style.css             │
│ & UX Specialist   │ Component Styling │ • public/app.js (UI Logic)     │
├───────────────────┼───────────────────┼────────────────────────────────┤
│ Member 2          │ Backend Core &    │ • server.js                    │
│ Backend Engineer  │ Security Engine   │ • routes/auth.js               │
│ & Auth Architect  │ JWT & Middleware  │ • middleware/authMiddleware.js │
├───────────────────┼───────────────────┼────────────────────────────────┤
│ Member 3          │ Database Engine & │ • database/db.js               │
│ Database Architect│ Marketplace APIs  │ • database/seed.js             │
│ & Systems Dev     │ Transactions      │ • routes/products.js           │
│                   │                   │ • routes/orders.js             │
├───────────────────┼───────────────────┼────────────────────────────────┤
│ Member 4          │ QA, Integration & │ • tests/test-api.js            │
│ QA Lead, DevOps   │ Technical Writing │ • docs/postman-collection.json │
│ & Video Presenter │ Demo Video Script │ • docs/* & README.md           │
└───────────────────┴───────────────────┴────────────────────────────────┘
```

---

## Detailed Member Breakdown

### Member 1: Frontend Design, Website Pages & UI/UX Specialist
- **Core Domain:** User interface architecture, styling system, component design, responsive layouts, and interactive DOM bindings.
- **Assigned Files:**
  - `public/index.html` (Semantic HTML5 markup for Home, Marketplace, Dashboards, and Modals)
  - `public/style.css` (Green/white/earthy CSS theme, typography, responsive flex/grid, micro-interactions)
  - `public/app.js` (DOM event listeners, modal controllers, client-side filtering, toast notifications)
- **Key Technical Contributions:**
  1. Built the responsive agricultural theme using CSS custom properties (`--primary: #1e5128`, `--earth: #78350f`).
  2. Implemented the Single-Page Application (SPA) client router that smoothly transitions between Home, Marketplace, Farmer Dashboard, Buyer Orders, and Admin views.
  3. Developed the real-time live order calculator that updates unit prices, quantities, and totals instantly in the order modal.
  4. Designed visual order status tracking progress bars (`Pending` ➔ `Accepted` ➔ `Shipped` ➔ `Delivered`).
- **Viva / Evaluation Talking Points for Member 1:**
  - *"How did you achieve a responsive layout without bulky CSS frameworks like Bootstrap?"*  
    **Answer:** Used native CSS Grid with `repeat(auto-fill, minmax(270px, 1fr))` for produce cards and flexbox with media queries at 992px and 640px for mobile adaptive drawers.
  - *"How does the frontend handle real-time feedback?"*  
    **Answer:** Implemented a non-blocking toast notification system and instant DOM updates reflecting stock changes after orders are accepted.

---

### Member 2: Backend Server, Authentication & Security Middleware
- **Core Domain:** Express.js routing infrastructure, password cryptography, JWT session management, centralized error handling, and Role-Based Access Control (RBAC).
- **Assigned Files:**
  - `server.js` (Express application initialization, middleware pipeline, static serving, graceful shutdown)
  - `routes/auth.js` (`/register`, `/login`, `/me` endpoints)
  - `middleware/authMiddleware.js` (`authenticateToken`, `authorizeRoles`)
- **Key Technical Contributions:**
  1. Configured secure JWT issuance with 7-day expiration and tamper-proof cryptographic signing.
  2. Implemented password hashing using `bcryptjs` with 10 salt rounds to eliminate plain-text password vulnerabilities.
  3. Designed role-based middleware that strictly enforces permissions so buyers cannot post crops and farmers cannot update products they do not own.
  4. Created centralized HTTP error handling middleware and graceful shutdown logic for database safety.
- **Viva / Evaluation Talking Points for Member 2:**
  - *"Why use JWT instead of traditional server-side session cookies?"*  
    **Answer:** JWTs are stateless, self-contained, and easily consumed by both web clients and API tools like Postman without requiring server memory for session stores.
  - *"How do you prevent unauthorized users from editing products?"*  
    **Answer:** Middleware verifies the JWT token and extracts the authenticated user ID and role. Route controllers verify that `product.farmer_id === req.user.id` unless the user has the `admin` role.

---

### Member 3: Database Architect & Core Business Logic (Products & Orders)
- **Core Domain:** SQLite relational schema design, indexes, transactional order processing, stock reconciliation, and CRUD API development.
- **Assigned Files:**
  - `database/db.js` (SQLite connection, WAL mode, foreign key enforcement, schema creation)
  - `database/seed.js` (Realistic demo data generation: farmers, buyers, crops, orders)
  - `routes/products.js` (Produce listing, search, category filter, update, delete)
  - `routes/orders.js` (Transactional order creation, stock deduction, role-based order views, status transitions)
  - `routes/admin.js` (Platform analytics and demo database reset)
- **Key Technical Contributions:**
  1. Configured SQLite with Write-Ahead Logging (`WAL`) and `PRAGMA foreign_keys = ON` for relational integrity.
  2. Designed an atomic SQLite transaction (`db.transaction`) for order creation to eliminate race conditions and prevent overselling stock.
  3. Implemented automated stock restoration: if an order is cancelled, stock is automatically returned to inventory.
  4. Formulated parameterized SQL queries with joins connecting products, farmers, buyers, and order history.
- **Viva / Evaluation Talking Points for Member 3:**
  - *"How do you prevent negative stock when multiple buyers order simultaneously?"*  
    **Answer:** Order placement is enclosed within an atomic transaction. The backend checks `product.quantity >= orderQty`. If insufficient, it throws an error and rolls back the transaction before any write occurs.
  - *"Why calculate order totals on the backend rather than trusting frontend prices?"*  
    **Answer:** Frontend input can be tampered with via dev tools or curl. The backend queries the canonical unit price directly from SQLite and computes `unit_price * quantity`.

---

### Member 4: API Testing, Integration, Documentation & Demo Video
- **Core Domain:** Test automation, Postman API collection authoring, end-to-end integration validation, system documentation, and presentation video production.
- **Assigned Files:**
  - `tests/test-api.js` (Comprehensive automated test suite covering 32 distinct assertions)
  - `docs/postman-collection.json` (Postman v2.1 exportable collection with test scripts)
  - `docs/demo-video-script.md` (Timed 2-3 minute video demonstration script with screen cues)
  - `docs/project-documentation.md` & `README.md` (Complete 19-section system report)
- **Key Technical Contributions:**
  1. Developed an in-memory automated test suite verifying all 32 critical business criteria without external testing frameworks.
  2. Built and validated the Postman Collection with pre-configured environment variables (`baseUrl`, `farmerToken`, `buyerToken`).
  3. Executed end-to-end integration testing simulating the complete Farmer-to-Buyer lifecycle.
  4. Authored clear, presentation-ready documentation and designed a 2.5-minute video recording script detailing screen actions and voiceovers.
- **Viva / Evaluation Talking Points for Member 4:**
  - *"What test cases were verified in your automated suite?"*  
    **Answer:** Verified 32 assertions including duplicate email rejection (409), password mismatch (401), unauthorized produce creation (403), transactional stock deduction, insufficient stock rejection (400), and order cancellation stock rollback.
  - *"How can judges immediately verify your APIs?"*  
    **Answer:** Import `docs/postman-collection.json` into Postman or run `npm test` in the terminal to execute all test cases in under 3 seconds.

