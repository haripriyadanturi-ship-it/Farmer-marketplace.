require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const { db } = require('./database/db');

const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const orderRoutes = require('./routes/orders');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request Logger
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    if (req.path.startsWith('/api')) {
      console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl} -> ${res.statusCode} (${duration}ms)`);
    }
  });
  next();
});

// Serve frontend static files
app.use(express.static(path.join(__dirname, 'public')));

// Health Check API
app.get('/api/health', (req, res) => {
  let dbStatus = 'healthy';
  try {
    db.prepare('SELECT 1').get();
  } catch (e) {
    dbStatus = 'unhealthy: ' + e.message;
  }

  res.status(200).json({
    status: 'online',
    project: 'FarmDirect - Farmer Marketplace',
    problemId: 'HACK-P309',
    database: dbStatus,
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Mount API routes
app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/admin', adminRoutes);

// Fallback for SPA routing to index.html for non-API routes
app.use((req, res, next) => {
  if (req.path.startsWith('/api')) {
    return res.status(404).json({
      success: false,
      message: `API route not found: ${req.method} ${req.originalUrl}`
    });
  }
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Centralized Error Handling Middleware
app.use((err, req, res, next) => {
  console.error('Unhandled Application Error:', err);

  const statusCode = err.statusCode || err.status || 500;
  const message = err.message || 'An unexpected internal server error occurred.';

  res.status(statusCode).json({
    success: false,
    message,
    ...(process.env.NODE_ENV === 'development' ? { stack: err.stack } : {})
  });
});

// Start Server only if executed directly
let server;
if (require.main === module) {
  server = app.listen(PORT, () => {
    console.log(`====================================================`);
    console.log(`🌾 FarmDirect (HACK-P309) Server Running!`);
    console.log(`🚀 URL: http://localhost:${PORT}`);
    console.log(`📦 Database: SQLite (database/farmer_marketplace.db)`);
    console.log(`👥 Hackathon Prototype Ready for Evaluation`);
    console.log(`====================================================`);
  });
}

// Graceful Shutdown
process.on('SIGINT', () => {
  console.log('\nGracefully shutting down server...');
  try {
    db.close();
    console.log('Database connection closed.');
  } catch (err) {
    console.error('Error closing database:', err);
  }
  if (server) {
    server.close(() => {
      console.log('HTTP server terminated.');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
});

module.exports = app;
