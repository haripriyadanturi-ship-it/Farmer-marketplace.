const express = require('express');
const router = express.Router();
const { db } = require('../database/db');
const { authenticateToken, authorizeRoles } = require('../middleware/authMiddleware');

/**
 * POST /api/orders
 * Place a new agricultural produce order (Buyer only)
 * Uses atomic SQLite database transaction to guarantee ACID consistency
 */
router.post('/', authenticateToken, authorizeRoles('buyer', 'admin'), (req, res, next) => {
  try {
    const { product_id, quantity, notes } = req.body;

    if (!product_id || quantity === undefined) {
      return res.status(400).json({
        success: false,
        message: 'Product ID and desired quantity are required.'
      });
    }

    const productId = parseInt(product_id, 10);
    const orderQty = Number(quantity);

    if (isNaN(productId) || productId <= 0) {
      return res.status(400).json({ success: false, message: 'Invalid product ID.' });
    }

    if (isNaN(orderQty) || orderQty <= 0) {
      return res.status(400).json({
        success: false,
        message: 'Quantity must be a positive number greater than zero.'
      });
    }

    const buyerId = req.user.id;

    // Execute atomic transaction for stock verification, deduction, and order record creation
    const executeOrderTransaction = db.transaction(() => {
      // 1. Fetch fresh product record
      const product = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);
      if (!product) {
        const err = new Error('The requested product does not exist.');
        err.statusCode = 404;
        throw err;
      }

      // 2. Validate available stock
      if (product.quantity < orderQty) {
        const err = new Error(
          `Insufficient stock. You requested ${orderQty} ${product.unit}, but only ${product.quantity} ${product.unit} are currently available.`
        );
        err.statusCode = 400;
        throw err;
      }

      // 3. Backend calculation of total price
      const totalPrice = Number((product.price * orderQty).toFixed(2));

      // 4. Reduce product stock
      const remainingStock = Number((product.quantity - orderQty).toFixed(2));
      db.prepare('UPDATE products SET quantity = ? WHERE id = ?').run(remainingStock, productId);

      // 5. Insert new order record
      const insertOrder = db.prepare(`
        INSERT INTO orders (buyer_id, product_id, quantity, total_price, status, notes)
        VALUES (?, ?, ?, ?, 'Pending', ?)
      `);

      const result = insertOrder.run(buyerId, productId, orderQty, totalPrice, notes ? notes.trim() : null);
      const newOrderId = result.lastInsertRowid;

      return {
        orderId: newOrderId,
        product,
        totalPrice,
        remainingStock
      };
    });

    let transactionResult;
    try {
      transactionResult = executeOrderTransaction();
    } catch (txErr) {
      return res.status(txErr.statusCode || 400).json({
        success: false,
        message: txErr.message
      });
    }

    // Fetch full order details with product and farmer information
    const fullOrder = db.prepare(`
      SELECT 
        o.id,
        o.buyer_id,
        o.product_id,
        o.quantity,
        o.total_price,
        o.status,
        o.notes,
        o.created_at,
        p.name AS product_name,
        p.category AS product_category,
        p.price AS unit_price,
        p.unit,
        p.image_url AS product_image,
        farmer.id AS farmer_id,
        farmer.name AS farmer_name,
        farmer.phone AS farmer_phone,
        farmer.location AS farmer_location
      FROM orders o
      JOIN products p ON o.product_id = p.id
      JOIN users farmer ON p.farmer_id = farmer.id
      WHERE o.id = ?
    `).get(transactionResult.orderId);

    return res.status(201).json({
      success: true,
      message: 'Order placed successfully! The farmer has been notified.',
      data: fullOrder
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/orders/my
 * Role-aware retrieval of orders:
 * - Buyers get orders they have placed
 * - Farmers get orders received for their listed produce
 * - Admins get all orders across the marketplace
 */
router.get('/my', authenticateToken, (req, res, next) => {
  try {
    const { role, id: userId } = req.user;

    let orders = [];

    if (role === 'buyer') {
      orders = db.prepare(`
        SELECT 
          o.id,
          o.buyer_id,
          o.product_id,
          o.quantity,
          o.total_price,
          o.status,
          o.notes,
          o.created_at,
          p.name AS product_name,
          p.category AS product_category,
          p.price AS unit_price,
          p.unit,
          p.image_url AS product_image,
          f.name AS farmer_name,
          f.phone AS farmer_phone,
          f.location AS farmer_location
        FROM orders o
        JOIN products p ON o.product_id = p.id
        JOIN users f ON p.farmer_id = f.id
        WHERE o.buyer_id = ?
        ORDER BY o.id DESC
      `).all(userId);
    } else if (role === 'farmer') {
      orders = db.prepare(`
        SELECT 
          o.id,
          o.buyer_id,
          o.product_id,
          o.quantity,
          o.total_price,
          o.status,
          o.notes,
          o.created_at,
          p.name AS product_name,
          p.category AS product_category,
          p.price AS unit_price,
          p.unit,
          p.image_url AS product_image,
          p.quantity AS current_stock,
          b.name AS buyer_name,
          b.email AS buyer_email,
          b.phone AS buyer_phone,
          b.location AS buyer_location
        FROM orders o
        JOIN products p ON o.product_id = p.id
        JOIN users b ON o.buyer_id = b.id
        WHERE p.farmer_id = ?
        ORDER BY o.id DESC
      `).all(userId);
    } else if (role === 'admin') {
      orders = db.prepare(`
        SELECT 
          o.id,
          o.buyer_id,
          o.product_id,
          o.quantity,
          o.total_price,
          o.status,
          o.notes,
          o.created_at,
          p.name AS product_name,
          p.category AS product_category,
          p.price AS unit_price,
          p.unit,
          f.name AS farmer_name,
          b.name AS buyer_name,
          b.email AS buyer_email
        FROM orders o
        JOIN products p ON o.product_id = p.id
        JOIN users f ON p.farmer_id = f.id
        JOIN users b ON o.buyer_id = b.id
        ORDER BY o.id DESC
      `).all();
    }

    res.status(200).json({
      success: true,
      count: orders.length,
      data: orders
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/orders/:id
 * Retrieve specific order details (Authorized buyer, farmer of that product, or admin)
 */
router.get('/:id', authenticateToken, (req, res, next) => {
  try {
    const orderId = parseInt(req.params.id, 10);
    if (isNaN(orderId)) {
      return res.status(400).json({ success: false, message: 'Invalid order ID.' });
    }

    const order = db.prepare(`
      SELECT 
        o.id,
        o.buyer_id,
        o.product_id,
        o.quantity,
        o.total_price,
        o.status,
        o.notes,
        o.created_at,
        p.name AS product_name,
        p.farmer_id,
        p.price AS unit_price,
        p.unit,
        p.image_url AS product_image,
        farmer.name AS farmer_name,
        farmer.phone AS farmer_phone,
        farmer.location AS farmer_location,
        buyer.name AS buyer_name,
        buyer.email AS buyer_email,
        buyer.phone AS buyer_phone,
        buyer.location AS buyer_location
      FROM orders o
      JOIN products p ON o.product_id = p.id
      JOIN users farmer ON p.farmer_id = farmer.id
      JOIN users buyer ON o.buyer_id = buyer.id
      WHERE o.id = ?
    `).get(orderId);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    // Authorization check: Must be buyer, farmer of the product, or admin
    if (
      req.user.role !== 'admin' &&
      order.buyer_id !== req.user.id &&
      order.farmer_id !== req.user.id
    ) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden. You are not authorized to view this order.'
      });
    }

    res.status(200).json({
      success: true,
      data: order
    });
  } catch (error) {
    next(error);
  }
});

/**
 * PATCH /api/orders/:id/status
 * Update order status (Farmer of the product, or Admin)
 * Allowed statuses: 'Pending', 'Accepted', 'Shipped', 'Delivered', 'Cancelled'
 */
router.patch('/:id/status', authenticateToken, authorizeRoles('farmer', 'admin'), (req, res, next) => {
  try {
    const orderId = parseInt(req.params.id, 10);
    const { status } = req.body;

    if (isNaN(orderId)) {
      return res.status(400).json({ success: false, message: 'Invalid order ID.' });
    }

    const validStatuses = ['Pending', 'Accepted', 'Shipped', 'Delivered', 'Cancelled'];
    if (!status || !validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Invalid status. Permitted statuses: ${validStatuses.join(', ')}`
      });
    }

    // Fetch order along with product info to check farmer ownership
    const order = db.prepare(`
      SELECT o.*, p.farmer_id, p.quantity AS current_stock
      FROM orders o
      JOIN products p ON o.product_id = p.id
      WHERE o.id = ?
    `).get(orderId);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found.' });
    }

    // Verify farmer ownership
    if (req.user.role !== 'admin' && order.farmer_id !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Security Violation: You can only update orders for products from your own farm.'
      });
    }

    // Atomic update, and if cancelling, return stock to product
    const updateTransaction = db.transaction(() => {
      // If moving from non-cancelled to Cancelled, return stock to product
      if (status === 'Cancelled' && order.status !== 'Cancelled') {
        db.prepare('UPDATE products SET quantity = quantity + ? WHERE id = ?')
          .run(order.quantity, order.product_id);
      }
      // If moving from Cancelled back to an active state, check and re-deduct
      else if (order.status === 'Cancelled' && status !== 'Cancelled') {
        const prod = db.prepare('SELECT quantity FROM products WHERE id = ?').get(order.product_id);
        if (prod.quantity < order.quantity) {
          throw new Error('Cannot reactivate order: insufficient stock available in inventory.');
        }
        db.prepare('UPDATE products SET quantity = quantity - ? WHERE id = ?')
          .run(order.quantity, order.product_id);
      }

      db.prepare('UPDATE orders SET status = ? WHERE id = ?').run(status, orderId);
    });

    try {
      updateTransaction();
    } catch (txErr) {
      return res.status(400).json({ success: false, message: txErr.message });
    }

    const updatedOrder = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);

    res.status(200).json({
      success: true,
      message: `Order #${orderId} status successfully updated to "${status}".`,
      data: updatedOrder
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;

