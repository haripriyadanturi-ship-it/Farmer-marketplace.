const express = require('express');
const router = express.Router();
const { db } = require('../database/db');
const { seedData } = require('../database/seed');
const { authenticateToken, authorizeRoles } = require('../middleware/authMiddleware');

/**
 * GET /api/admin/stats
 * Overview statistics of the platform
 */
router.get('/stats', authenticateToken, authorizeRoles('admin'), (req, res, next) => {
  try {
    const totalFarmers = db.prepare("SELECT COUNT(*) as count FROM users WHERE role = 'farmer'").get().count;
    const totalBuyers = db.prepare("SELECT COUNT(*) as count FROM users WHERE role = 'buyer'").get().count;
    const totalProducts = db.prepare('SELECT COUNT(*) as count FROM products').get().count;
    const totalOrders = db.prepare('SELECT COUNT(*) as count FROM orders').get().count;

    const gmvResult = db.prepare("SELECT COALESCE(SUM(total_price), 0) as total FROM orders WHERE status != 'Cancelled'").get();
    const totalRevenue = gmvResult.total;

    const ordersByStatus = db.prepare(`
      SELECT status, COUNT(*) as count
      FROM orders
      GROUP BY status
    `).all();

    const lowStockProducts = db.prepare(`
      SELECT id, name, quantity, unit, price
      FROM products
      WHERE quantity < 20
      ORDER BY quantity ASC
    `).all();

    res.status(200).json({
      success: true,
      stats: {
        totalFarmers,
        totalBuyers,
        totalProducts,
        totalOrders,
        totalRevenue,
        ordersByStatus,
        lowStockProducts
      }
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/admin/users
 * List all users without sensitive fields
 */
router.get('/users', authenticateToken, authorizeRoles('admin'), (req, res, next) => {
  try {
    const users = db.prepare(`
      SELECT id, name, email, role, phone, location, created_at
      FROM users
      ORDER BY id ASC
    `).all();

    res.status(200).json({
      success: true,
      count: users.length,
      users
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/admin/seed-reset
 * Reset demo data for clean hackathon judging demonstrations
 */
router.post('/seed-reset', (req, res, next) => {
  try {
    // Allows demo reset either with admin auth or hackathon passkey
    const { passkey } = req.body;
    const authHeader = req.headers['authorization'];

    let isAuthorized = false;
    if (passkey === 'hackathon-p309' || passkey === 'demo-reset') {
      isAuthorized = true;
    } else if (authHeader) {
      // check token
      try {
        const jwt = require('jsonwebtoken');
        const { JWT_SECRET } = require('../middleware/authMiddleware');
        const token = authHeader.split(' ')[1];
        const decoded = jwt.verify(token, JWT_SECRET);
        if (decoded.role === 'admin') isAuthorized = true;
      } catch (e) {
        // invalid token
      }
    }

    if (!isAuthorized) {
      return res.status(403).json({
        success: false,
        message: 'Unauthorized demo reset. Passkey "hackathon-p309" or admin login required.'
      });
    }

    seedData();

    res.status(200).json({
      success: true,
      message: 'FarmDirect database has been cleanly re-seeded with demo data!'
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;

