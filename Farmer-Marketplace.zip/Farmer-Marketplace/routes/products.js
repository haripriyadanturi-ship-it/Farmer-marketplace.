const express = require('express');
const router = express.Router();
const { db } = require('../database/db');
const { authenticateToken, authorizeRoles } = require('../middleware/authMiddleware');

/**
 * GET /api/products
 * Fetch products with optional search and category filters
 */
router.get('/', (req, res, next) => {
  try {
    const { q, category, farmer_id, min_price, max_price, in_stock } = req.query;

    let query = `
      SELECT 
        p.id,
        p.farmer_id,
        p.name,
        p.category,
        p.price,
        p.quantity,
        p.unit,
        p.description,
        p.image_url,
        p.created_at,
        u.name AS farmer_name,
        u.email AS farmer_email,
        u.phone AS farmer_phone,
        u.location AS farmer_location
      FROM products p
      JOIN users u ON p.farmer_id = u.id
      WHERE 1=1
    `;

    const params = [];

    // Search filter
    if (q && q.trim()) {
      query += ` AND (p.name LIKE ? OR p.description LIKE ?)`;
      const searchTerm = `%${q.trim()}%`;
      params.push(searchTerm, searchTerm);
    }

    // Category filter
    if (category && category.trim() && category.toLowerCase() !== 'all') {
      query += ` AND LOWER(p.category) = LOWER(?)`;
      params.push(category.trim());
    }

    // Farmer filter
    if (farmer_id) {
      query += ` AND p.farmer_id = ?`;
      params.push(parseInt(farmer_id, 10));
    }

    // Price range filters
    if (min_price && !isNaN(Number(min_price))) {
      query += ` AND p.price >= ?`;
      params.push(Number(min_price));
    }
    if (max_price && !isNaN(Number(max_price))) {
      query += ` AND p.price <= ?`;
      params.push(Number(max_price));
    }

    // In stock filter
    if (in_stock === 'true') {
      query += ` AND p.quantity > 0`;
    }

    query += ` ORDER BY p.id DESC`;

    const products = db.prepare(query).all(...params);

    res.status(200).json({
      success: true,
      count: products.length,
      data: products
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/products/categories
 * Returns unique categories available in the marketplace
 */
router.get('/categories', (req, res, next) => {
  try {
    const rows = db.prepare('SELECT DISTINCT category FROM products ORDER BY category ASC').all();
    const categories = rows.map(r => r.category);
    res.status(200).json({
      success: true,
      categories
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/products/:id
 * Fetch a single product by ID
 */
router.get('/:id', (req, res, next) => {
  try {
    const productId = parseInt(req.params.id, 10);
    if (isNaN(productId)) {
      return res.status(400).json({ success: false, message: 'Invalid product ID.' });
    }

    const product = db.prepare(`
      SELECT 
        p.id,
        p.farmer_id,
        p.name,
        p.category,
        p.price,
        p.quantity,
        p.unit,
        p.description,
        p.image_url,
        p.created_at,
        u.name AS farmer_name,
        u.email AS farmer_email,
        u.phone AS farmer_phone,
        u.location AS farmer_location
      FROM products p
      JOIN users u ON p.farmer_id = u.id
      WHERE p.id = ?
    `).get(productId);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found.'
      });
    }

    res.status(200).json({
      success: true,
      data: product
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/products
 * Add a new agricultural produce item (Farmer or Admin only)
 */
router.post('/', authenticateToken, authorizeRoles('farmer', 'admin'), (req, res, next) => {
  try {
    const { name, category, price, quantity, unit, description, image_url } = req.body;

    if (!name || !category || price === undefined || quantity === undefined) {
      return res.status(400).json({
        success: false,
        message: 'Name, category, price, and available quantity are required.'
      });
    }

    const numPrice = Number(price);
    const numQuantity = Number(quantity);

    if (isNaN(numPrice) || numPrice < 0) {
      return res.status(400).json({
        success: false,
        message: 'Price must be a valid non-negative number.'
      });
    }

    if (isNaN(numQuantity) || numQuantity < 0) {
      return res.status(400).json({
        success: false,
        message: 'Quantity must be a valid non-negative number.'
      });
    }

    // Default image if not provided
    const finalImageUrl = image_url && image_url.trim()
      ? image_url.trim()
      : 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600&auto=format&fit=crop&q=80';

    const farmerId = req.user.role === 'admin' && req.body.farmer_id
      ? parseInt(req.body.farmer_id, 10)
      : req.user.id;

    const stmt = db.prepare(`
      INSERT INTO products (farmer_id, name, category, price, quantity, unit, description, image_url)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const result = stmt.run(
      farmerId,
      name.trim(),
      category.trim(),
      numPrice,
      numQuantity,
      (unit || 'kg').trim(),
      description ? description.trim() : '',
      finalImageUrl
    );

    const createdProduct = db.prepare(`
      SELECT p.*, u.name as farmer_name
      FROM products p
      JOIN users u ON p.farmer_id = u.id
      WHERE p.id = ?
    `).get(result.lastInsertRowid);

    res.status(201).json({
      success: true,
      message: 'Product listed successfully on the marketplace!',
      data: createdProduct
    });
  } catch (error) {
    next(error);
  }
});

/**
 * PUT /api/products/:id
 * Update an existing product listing (Farmer owns it, or Admin)
 */
router.put('/:id', authenticateToken, authorizeRoles('farmer', 'admin'), (req, res, next) => {
  try {
    const productId = parseInt(req.params.id, 10);
    if (isNaN(productId)) {
      return res.status(400).json({ success: false, message: 'Invalid product ID.' });
    }

    // Check existing product
    const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    // Ownership security check
    if (req.user.role !== 'admin' && existing.farmer_id !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Security Violation: You can only edit products that belong to your farm.'
      });
    }

    const { name, category, price, quantity, unit, description, image_url } = req.body;

    const updatedName = name !== undefined ? name.trim() : existing.name;
    const updatedCategory = category !== undefined ? category.trim() : existing.category;
    const updatedPrice = price !== undefined ? Number(price) : existing.price;
    const updatedQuantity = quantity !== undefined ? Number(quantity) : existing.quantity;
    const updatedUnit = unit !== undefined ? unit.trim() : existing.unit;
    const updatedDesc = description !== undefined ? description.trim() : existing.description;
    const updatedImg = image_url !== undefined && image_url.trim() ? image_url.trim() : existing.image_url;

    if (isNaN(updatedPrice) || updatedPrice < 0) {
      return res.status(400).json({ success: false, message: 'Price must be a valid positive number.' });
    }
    if (isNaN(updatedQuantity) || updatedQuantity < 0) {
      return res.status(400).json({ success: false, message: 'Quantity must be a valid positive number.' });
    }

    const stmt = db.prepare(`
      UPDATE products
      SET name = ?, category = ?, price = ?, quantity = ?, unit = ?, description = ?, image_url = ?
      WHERE id = ?
    `);

    stmt.run(updatedName, updatedCategory, updatedPrice, updatedQuantity, updatedUnit, updatedDesc, updatedImg, productId);

    const updated = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);

    res.status(200).json({
      success: true,
      message: 'Product updated successfully!',
      data: updated
    });
  } catch (error) {
    next(error);
  }
});

/**
 * DELETE /api/products/:id
 * Delete a product listing (Farmer owns it, or Admin)
 */
router.delete('/:id', authenticateToken, authorizeRoles('farmer', 'admin'), (req, res, next) => {
  try {
    const productId = parseInt(req.params.id, 10);
    if (isNaN(productId)) {
      return res.status(400).json({ success: false, message: 'Invalid product ID.' });
    }

    const existing = db.prepare('SELECT * FROM products WHERE id = ?').get(productId);
    if (!existing) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    // Ownership security check
    if (req.user.role !== 'admin' && existing.farmer_id !== req.user.id) {
      return res.status(403).json({
        success: false,
        message: 'Security Violation: You can only delete products that belong to your farm.'
      });
    }

    // Check if there are active orders for this product
    const orderCount = db.prepare('SELECT COUNT(*) as count FROM orders WHERE product_id = ?').get(productId);
    if (orderCount.count > 0) {
      // If orders exist, soft-retire by setting quantity to 0 and appending [Archived] or delete order constraints
      // SQLite RESTRICT will throw foreign key error if orders reference it.
      // Let's check: if orders exist, we can mark quantity = 0 and prepend '[Archived] ' so past orders retain reference,
      // or we can safely handle it:
      return res.status(400).json({
        success: false,
        message: `Cannot delete product because it has ${orderCount.count} recorded order(s) for audit history. You can set stock quantity to 0 instead.`
      });
    }

    db.prepare('DELETE FROM products WHERE id = ?').run(productId);

    res.status(200).json({
      success: true,
      message: 'Product listing deleted successfully.'
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;

