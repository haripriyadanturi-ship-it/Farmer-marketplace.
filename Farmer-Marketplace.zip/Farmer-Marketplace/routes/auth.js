const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('../database/db');
const { JWT_SECRET, authenticateToken } = require('../middleware/authMiddleware');

/**
 * POST /api/auth/register
 * Register a new user (Farmer or Buyer)
 */
router.post('/register', async (req, res, next) => {
  try {
    const { name, email, password, role, phone, location } = req.body;

    // 1. Validation
    if (!name || !email || !password || !role) {
      return res.status(400).json({
        success: false,
        message: 'Name, email, password, and role are required fields.'
      });
    }

    const trimmedEmail = email.trim().toLowerCase();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid email address.'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.'
      });
    }

    const normalizedRole = role.toLowerCase().trim();
    if (!['farmer', 'buyer'].includes(normalizedRole)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid role. Public registration only allows "farmer" or "buyer".'
      });
    }

    // 2. Check for duplicate email
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(trimmedEmail);
    if (existing) {
      return res.status(409).json({
        success: false,
        message: 'An account with this email address already exists. Please log in.'
      });
    }

    // 3. Hash password
    const saltRounds = 10;
    const password_hash = await bcrypt.hash(password, saltRounds);

    // 4. Insert into database
    const insertStmt = db.prepare(`
      INSERT INTO users (name, email, password_hash, role, phone, location)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    const result = insertStmt.run(
      name.trim(),
      trimmedEmail,
      password_hash,
      normalizedRole,
      phone ? phone.trim() : null,
      location ? location.trim() : null
    );

    const newUser = {
      id: result.lastInsertRowid,
      name: name.trim(),
      email: trimmedEmail,
      role: normalizedRole,
      phone: phone ? phone.trim() : null,
      location: location ? location.trim() : null
    };

    // 5. Generate JWT token
    const token = jwt.sign(
      { id: newUser.id, email: newUser.email, role: newUser.role, name: newUser.name },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.status(201).json({
      success: true,
      message: `${normalizedRole.toUpperCase()} account registered successfully!`,
      token,
      user: newUser
    });
  } catch (error) {
    next(error);
  }
});

/**
 * POST /api/auth/login
 * Log in using email and password
 */
router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both email and password.'
      });
    }

    const trimmedEmail = email.trim().toLowerCase();

    // Query user
    const user = db.prepare(`
      SELECT id, name, email, password_hash, role, phone, location, created_at
      FROM users
      WHERE email = ?
    `).get(trimmedEmail);

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.'
      });
    }

    // Compare password
    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Invalid email or password.'
      });
    }

    // Generate JWT token
    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, name: user.name },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.status(200).json({
      success: true,
      message: `Welcome back, ${user.name}!`,
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        location: user.location,
        created_at: user.created_at
      }
    });
  } catch (error) {
    next(error);
  }
});

/**
 * GET /api/auth/me
 * Get current authenticated user details
 */
router.get('/me', authenticateToken, (req, res, next) => {
  try {
    const user = db.prepare(`
      SELECT id, name, email, role, phone, location, created_at
      FROM users
      WHERE id = ?
    `).get(req.user.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User profile not found.'
      });
    }

    res.status(200).json({
      success: true,
      user
    });
  } catch (error) {
    next(error);
  }
});

module.exports = router;

