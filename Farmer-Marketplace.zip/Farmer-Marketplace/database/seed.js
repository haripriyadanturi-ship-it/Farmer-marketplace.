const bcrypt = require('bcryptjs');
const { db, initDatabase } = require('./db');

function seedData() {
  initDatabase();

  console.log('🌱 Starting database seeding for FarmDirect...');

  // Check if users already exist
  const existingUsers = db.prepare('SELECT COUNT(*) as count FROM users').get();
  if (existingUsers.count > 0) {
    console.log(`ℹ️ Database already has ${existingUsers.count} users. Cleaning up previous demo data...`);
    db.exec(`
      DELETE FROM orders;
      DELETE FROM products;
      DELETE FROM users;
      DELETE FROM sqlite_sequence WHERE name IN ('orders', 'products', 'users');
    `);
  }

  // Common demo passwords hashed with bcrypt (salt rounds = 10)
  const farmerPassword = bcrypt.hashSync('Farmer@123', 10);
  const buyerPassword = bcrypt.hashSync('Buyer@123', 10);
  const adminPassword = bcrypt.hashSync('Admin@123', 10);

  // Insert Users
  const insertUser = db.prepare(`
    INSERT INTO users (name, email, password_hash, role, phone, location)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  const users = [
    {
      name: 'Ramesh Patel',
      email: 'ramesh.farmer@farmdirect.com',
      password: farmerPassword,
      role: 'farmer',
      phone: '+91 98765 43210',
      location: 'Anand, Gujarat'
    },
    {
      name: 'Sunita Sharma',
      email: 'sunita.farmer@farmdirect.com',
      password: farmerPassword,
      role: 'farmer',
      phone: '+91 98123 45678',
      location: 'Ludhiana, Punjab'
    },
    {
      name: 'Rajesh Kumar',
      email: 'rajesh.farmer@farmdirect.com',
      password: farmerPassword,
      role: 'farmer',
      phone: '+91 97654 32109',
      location: 'Shimla, Himachal Pradesh'
    },
    {
      name: 'Priya Verma',
      email: 'priya.buyer@farmdirect.com',
      password: buyerPassword,
      role: 'buyer',
      phone: '+91 99887 76655',
      location: 'Kothrud, Pune'
    },
    {
      name: 'Amit Sen',
      email: 'amit.buyer@farmdirect.com',
      password: buyerPassword,
      role: 'buyer',
      phone: '+91 91234 56780',
      location: 'Andheri West, Mumbai'
    },
    {
      name: 'FarmDirect Administrator',
      email: 'admin@farmdirect.com',
      password: adminPassword,
      role: 'admin',
      phone: '+91 80000 12345',
      location: 'Bengaluru HQ'
    }
  ];

  const userIds = {};
  for (const u of users) {
    const res = insertUser.run(u.name, u.email, u.password, u.role, u.phone, u.location);
    userIds[u.email] = res.lastInsertRowid;
  }
  console.log(`✅ Created ${users.length} demo users (Farmers, Buyers, Admin).`);

  // Insert Products
  const insertProduct = db.prepare(`
    INSERT INTO products (farmer_id, name, category, price, quantity, unit, description, image_url)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const products = [
    {
      farmer_id: userIds['ramesh.farmer@farmdirect.com'],
      name: 'Fresh Vine Tomatoes (Desi)',
      category: 'Vegetables',
      price: 35.0,
      quantity: 240,
      unit: 'kg',
      description: 'Naturally ripened, pesticide-free fresh desi tomatoes harvested this morning. Juicy and rich in flavor.',
      image_url: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600&auto=format&fit=crop&q=80'
    },
    {
      farmer_id: userIds['rajesh.farmer@farmdirect.com'],
      name: 'Royal Shimla Red Apples',
      category: 'Fruits',
      price: 150.0,
      quantity: 180,
      unit: 'kg',
      description: 'Crisp, sweet, and hand-picked from high-altitude Shimla orchards. 100% natural wax-free harvest.',
      image_url: 'https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=600&auto=format&fit=crop&q=80'
    },
    {
      farmer_id: userIds['sunita.farmer@farmdirect.com'],
      name: 'Traditional Basmati Rice (1121)',
      category: 'Grains & Cereals',
      price: 90.0,
      quantity: 500,
      unit: 'kg',
      description: 'Aged extra-long grain aromatic Basmati rice from the fertile plains of Punjab. Exceptional aroma.',
      image_url: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=600&auto=format&fit=crop&q=80'
    },
    {
      farmer_id: userIds['ramesh.farmer@farmdirect.com'],
      name: 'Farm Fresh Organic Spinach (Palak)',
      category: 'Vegetables',
      price: 25.0,
      quantity: 95,
      unit: 'bunch',
      description: 'Tender, nutrient-rich green spinach cultivated with organic compost and drip irrigation.',
      image_url: 'https://images.unsplash.com/photo-1576045057995-568f588f82fb?w=600&auto=format&fit=crop&q=80'
    },
    {
      farmer_id: userIds['ramesh.farmer@farmdirect.com'],
      name: 'Pure Gir Cow A2 Milk',
      category: 'Dairy & Eggs',
      price: 75.0,
      quantity: 60,
      unit: 'litre',
      description: 'Raw, unadulterated whole A2 milk from grass-fed indigenous Gir cows. Bottled hygienically.',
      image_url: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=600&auto=format&fit=crop&q=80'
    },
    {
      farmer_id: userIds['rajesh.farmer@farmdirect.com'],
      name: 'Ratnagiri Alphonso Mangoes (Hapus)',
      category: 'Fruits',
      price: 650.0,
      quantity: 40,
      unit: 'dozen',
      description: 'GI-tagged authentic Ratnagiri Alphonso mangoes. Golden yellow skin, heavenly scent, fiberless pulp.',
      image_url: 'https://images.unsplash.com/photo-1553279768-865429fa0078?w=600&auto=format&fit=crop&q=80'
    },
    {
      farmer_id: userIds['sunita.farmer@farmdirect.com'],
      name: 'Organic Salem Turmeric Powder',
      category: 'Herbs & Spices',
      price: 220.0,
      quantity: 75,
      unit: 'kg',
      description: 'Sun-dried and stone-ground turmeric with high curcumin content (>5%). No artificial coloring.',
      image_url: 'https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=600&auto=format&fit=crop&q=80'
    },
    {
      farmer_id: userIds['rajesh.farmer@farmdirect.com'],
      name: 'Fresh White Button Mushrooms',
      category: 'Vegetables',
      price: 50.0,
      quantity: 110,
      unit: 'pack',
      description: 'Freshly harvested button mushrooms grown in temperature-controlled organic substrate beds.',
      image_url: 'https://images.unsplash.com/photo-1504544750208-dc0358e63f7f?w=600&auto=format&fit=crop&q=80'
    }
  ];

  const productIds = [];
  for (const p of products) {
    const res = insertProduct.run(
      p.farmer_id,
      p.name,
      p.category,
      p.price,
      p.quantity,
      p.unit,
      p.description,
      p.image_url
    );
    productIds.push(res.lastInsertRowid);
  }
  console.log(`✅ Created ${products.length} agricultural produce listings.`);

  // Insert Sample Orders
  const insertOrder = db.prepare(`
    INSERT INTO orders (buyer_id, product_id, quantity, total_price, status, notes, created_at)
    VALUES (?, ?, ?, ?, ?, ?, datetime('now', ?))
  `);

  const sampleOrders = [
    {
      buyer_id: userIds['priya.buyer@farmdirect.com'],
      product_id: productIds[0], // Vine Tomatoes (price 35)
      quantity: 10,
      total_price: 350.0,
      status: 'Pending',
      notes: 'Please ensure packaging is well-aerated.',
      offset: '-1 hours'
    },
    {
      buyer_id: userIds['amit.buyer@farmdirect.com'],
      product_id: productIds[1], // Shimla Apples (price 150)
      quantity: 5,
      total_price: 750.0,
      status: 'Accepted',
      notes: 'For family fruit basket.',
      offset: '-5 hours'
    },
    {
      buyer_id: userIds['priya.buyer@farmdirect.com'],
      product_id: productIds[2], // Basmati Rice (price 90)
      quantity: 25,
      total_price: 2250.0,
      status: 'Shipped',
      notes: 'Monthly grocery refill.',
      offset: '-1 days'
    },
    {
      buyer_id: userIds['amit.buyer@farmdirect.com'],
      product_id: productIds[4], // Gir Cow Milk (price 75)
      quantity: 4,
      total_price: 300.0,
      status: 'Delivered',
      notes: 'Morning delivery appreciated.',
      offset: '-2 days'
    }
  ];

  for (const ord of sampleOrders) {
    insertOrder.run(ord.buyer_id, ord.product_id, ord.quantity, ord.total_price, ord.status, ord.notes, ord.offset);
  }
  console.log(`✅ Created ${sampleOrders.length} sample orders across multiple stages.`);

  console.log('🎉 FarmDirect database seeding complete successfully!');
}

if (require.main === module) {
  seedData();
}

module.exports = { seedData };

