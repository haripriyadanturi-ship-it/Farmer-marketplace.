/**
 * FarmDirect (HACK-P309) - Client Application Logic
 * Pure Vanilla JavaScript (ES6+), Zero External Framework Dependencies
 */

// ==========================================================================
// APPLICATION STATE
// ==========================================================================
const AppState = {
  user: null,
  token: null,
  currentView: 'home',
  products: [],
  filteredProducts: [],
  categories: [],
  filters: {
    category: 'All',
    search: '',
    sort: 'newest',
    inStock: true
  },
  selectedProductForOrder: null,
  buyerOrders: [],
  farmerOrders: [],
  farmerProducts: []
};

// ==========================================================================
// INITIALIZATION
// ==========================================================================
document.addEventListener('DOMContentLoaded', () => {
  initAuthFromStorage();
  initRouting();
  initEventListeners();
  loadInitialData();
});

function initAuthFromStorage() {
  const savedToken = localStorage.getItem('farmdirect_token');
  const savedUser = localStorage.getItem('farmdirect_user');

  if (savedToken && savedUser) {
    try {
      AppState.token = savedToken;
      AppState.user = JSON.parse(savedUser);
      updateAuthUI();
    } catch (e) {
      console.error('Error parsing stored user:', e);
      clearAuth();
    }
  } else {
    updateAuthUI();
  }
}

function clearAuth() {
  AppState.token = null;
  AppState.user = null;
  localStorage.removeItem('farmdirect_token');
  localStorage.removeItem('farmdirect_user');
  updateAuthUI();
}

function updateAuthUI() {
  const guestControls = document.getElementById('guestControls');
  const userControls = document.getElementById('userControls');
  const navFarmer = document.querySelector('.nav-auth-farmer');
  const navBuyer = document.querySelector('.nav-auth-buyer');
  const navAdmin = document.querySelector('.nav-auth-admin');

  if (AppState.user && AppState.token) {
    guestControls.style.display = 'none';
    userControls.style.display = 'flex';

    document.getElementById('userName').textContent = AppState.user.name;
    document.getElementById('userRole').textContent = AppState.user.role;
    
    // Set avatar icon
    const avatar = document.getElementById('userAvatar');
    if (AppState.user.role === 'farmer') avatar.textContent = '👨‍🌾';
    else if (AppState.user.role === 'admin') avatar.textContent = '🛡️';
    else avatar.textContent = '🛒';

    // Show role-specific nav
    navFarmer.style.display = AppState.user.role === 'farmer' ? 'inline-block' : 'none';
    navBuyer.style.display = AppState.user.role === 'buyer' ? 'inline-block' : 'none';
    navAdmin.style.display = AppState.user.role === 'admin' ? 'inline-block' : 'none';
  } else {
    guestControls.style.display = 'flex';
    userControls.style.display = 'none';
    navFarmer.style.display = 'none';
    navBuyer.style.display = 'none';
    navAdmin.style.display = 'none';
  }
}

// ==========================================================================
// API HELPER
// ==========================================================================
async function apiCall(endpoint, method = 'GET', body = null) {
  const headers = { 'Content-Type': 'application/json' };

  if (AppState.token) {
    headers['Authorization'] = `Bearer ${AppState.token}`;
  }

  const options = { method, headers };
  if (body) {
    options.body = JSON.stringify(body);
  }

  try {
    const response = await fetch(endpoint, options);
    const data = await response.json();

    if (response.status === 401 && AppState.token) {
      // Session expired or invalid
      showToast('Session expired. Please log in again.', 'info');
      clearAuth();
      navigateTo('home');
      return { success: false, message: 'Session expired' };
    }

    return { ...data, statusCode: response.status };
  } catch (err) {
    console.error(`API Call failed (${endpoint}):`, err);
    return {
      success: false,
      message: 'Network error or server unreachable. Please make sure server is running on localhost:3000.'
    };
  }
}

// ==========================================================================
// ROUTING & VIEW NAVIGATION
// ==========================================================================
function initRouting() {
  window.addEventListener('hashchange', handleHashRoute);
  handleHashRoute();
}

function handleHashRoute() {
  const hash = window.location.hash.replace('#', '') || 'home';
  navigateTo(hash);
}

function navigateTo(viewName) {
  // Guard protected routes
  if (viewName === 'farmer-dashboard' && (!AppState.user || AppState.user.role !== 'farmer')) {
    showToast('Please log in with a Farmer account to access the Farmer Portal.', 'error');
    openAuthModal('login');
    return;
  }
  if (viewName === 'buyer-orders' && (!AppState.user || AppState.user.role !== 'buyer')) {
    showToast('Please log in as a Buyer to view your orders.', 'error');
    openAuthModal('login');
    return;
  }
  if (viewName === 'admin-dashboard' && (!AppState.user || AppState.user.role !== 'admin')) {
    showToast('Administrative privileges required.', 'error');
    openAuthModal('login');
    return;
  }

  // Update hash if different
  if (window.location.hash !== `#${viewName}`) {
    history.pushState(null, '', `#${viewName}`);
  }

  AppState.currentView = viewName;

  // Toggle active view sections
  const views = {
    'home': document.getElementById('viewHome'),
    'marketplace': document.getElementById('viewMarketplace'),
    'farmer-dashboard': document.getElementById('viewFarmerDashboard'),
    'buyer-orders': document.getElementById('viewBuyerOrders'),
    'admin-dashboard': document.getElementById('viewAdminDashboard')
  };

  Object.keys(views).forEach(k => {
    if (views[k]) {
      views[k].classList.toggle('active', k === viewName);
    }
  });

  // Update navbar links
  document.querySelectorAll('.main-nav .nav-link').forEach(link => {
    link.classList.toggle('active', link.dataset.view === viewName);
  });

  // Scroll to top
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Close mobile nav drawer if open
  document.getElementById('mainNav').classList.remove('open');

  // Trigger data reload for specific views
  if (viewName === 'home') {
    loadFeaturedProducts();
  } else if (viewName === 'marketplace') {
    fetchMarketplaceProducts();
  } else if (viewName === 'farmer-dashboard') {
    loadFarmerDashboard();
  } else if (viewName === 'buyer-orders') {
    loadBuyerOrders();
  } else if (viewName === 'admin-dashboard') {
    loadAdminDashboard();
  }
}

// ==========================================================================
// DATA LOADING FUNCTIONS
// ==========================================================================
async function loadInitialData() {
  await loadFeaturedProducts();
}

async function loadFeaturedProducts() {
  const container = document.getElementById('featuredProduceGrid');
  if (!container) return;

  const res = await apiCall('/api/products');
  if (res.success && res.data) {
    AppState.products = res.data;
    // Show top 4 in featured
    const featured = res.data.slice(0, 4);
    renderProduceGrid(featured, container);
  } else {
    container.innerHTML = `<div class="empty-state"><p>Unable to load featured products.</p></div>`;
  }
}

async function fetchMarketplaceProducts() {
  const container = document.getElementById('marketplaceProduceGrid');
  const counter = document.getElementById('resultsCount');
  
  container.innerHTML = `
    <div class="loading-state">
      <div class="spinner"></div>
      <p>Fetching fresh agricultural produce...</p>
    </div>
  `;

  // Build query string
  const params = new URLSearchParams();
  if (AppState.filters.search) params.append('q', AppState.filters.search);
  if (AppState.filters.category && AppState.filters.category !== 'All') {
    params.append('category', AppState.filters.category);
  }
  if (AppState.filters.inStock) params.append('in_stock', 'true');

  const res = await apiCall(`/api/products?${params.toString()}`);
  if (res.success && res.data) {
    let list = res.data;

    // Client-side sorting
    if (AppState.filters.sort === 'price-low') {
      list.sort((a, b) => a.price - b.price);
    } else if (AppState.filters.sort === 'price-high') {
      list.sort((a, b) => b.price - a.price);
    } else if (AppState.filters.sort === 'stock-high') {
      list.sort((a, b) => b.quantity - a.quantity);
    }

    AppState.filteredProducts = list;
    counter.textContent = `Showing ${list.length} produce listings`;
    renderProduceGrid(list, container);
  } else {
    container.innerHTML = `<div class="empty-state"><p>Error loading produce catalog.</p></div>`;
    counter.textContent = '0 listings found';
  }
}

function renderProduceGrid(productsList, containerElement) {
  if (!productsList || productsList.length === 0) {
    containerElement.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">🌾</div>
        <h3>No agricultural produce found</h3>
        <p>No current listings match your search or filter criteria. Try clearing filters.</p>
        <button class="btn btn-outline btn-sm" onclick="resetFilters()">Reset All Filters</button>
      </div>
    `;
    return;
  }

  containerElement.innerHTML = productsList.map(item => {
    const isOutOfStock = item.quantity <= 0;
    const stockClass = isOutOfStock ? 'stock-out' : (item.quantity < 20 ? 'stock-low' : 'stock-in');
    const stockText = isOutOfStock ? 'Out of Stock' : `${item.quantity} ${item.unit} available`;

    return `
      <div class="produce-card" data-id="${item.id}">
        <div class="produce-img-wrap">
          <img src="${escapeHtml(item.image_url || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600')}" 
               alt="${escapeHtml(item.name)}" 
               class="produce-img" 
               loading="lazy"
               onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1542838132-92c53300491e?w=600'">
          <span class="produce-cat-badge">${escapeHtml(item.category)}</span>
          <span class="produce-stock-badge ${stockClass}">● ${stockText}</span>
        </div>

        <div class="produce-card-body">
          <div class="produce-farmer-meta">
            <span>👨‍🌾 ${escapeHtml(item.farmer_name)}</span>
            ${item.farmer_location ? `<span>• 📍 ${escapeHtml(item.farmer_location)}</span>` : ''}
          </div>

          <h3 class="produce-title">${escapeHtml(item.name)}</h3>
          <p class="produce-desc">${escapeHtml(item.description || 'Freshly harvested produce directly from certified regional farms.')}</p>

          <div class="produce-card-footer">
            <div class="produce-pricing">
              <span class="price-main">₹${Number(item.price).toFixed(2)}</span>
              <span class="price-unit">per ${escapeHtml(item.unit)}</span>
            </div>

            <button class="btn btn-sm ${isOutOfStock ? 'btn-outline' : 'btn-primary'} btn-order-produce" 
                    data-id="${item.id}" 
                    ${isOutOfStock ? 'disabled' : ''}>
              ${isOutOfStock ? 'Out of Stock' : '🛒 Order Now'}
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

// ==========================================================================
// ORDER PLACEMENT WORKFLOW
// ==========================================================================
function openOrderModal(productId) {
  // If guest, prompt login
  if (!AppState.user || !AppState.token) {
    showToast('Please log in or create an account to place an order.', 'info');
    openAuthModal('login');
    return;
  }

  // If user is a farmer, advise that orders are typically placed by buyers
  if (AppState.user.role === 'farmer') {
    const proceed = confirm('You are currently logged in as a Farmer. Produce orders are typically placed by Buyers. Would you like to proceed or switch to a Buyer demo account?');
    if (!proceed) return;
  }

  // Find product from memory or fetch
  const product = AppState.products.find(p => p.id === parseInt(productId, 10)) 
               || AppState.filteredProducts.find(p => p.id === parseInt(productId, 10));

  if (!product) {
    showToast('Product information could not be retrieved.', 'error');
    return;
  }

  AppState.selectedProductForOrder = product;

  // Populate order modal fields
  document.getElementById('orderProductId').value = product.id;
  document.getElementById('orderProdImg').src = product.image_url;
  document.getElementById('orderProdName').textContent = product.name;
  document.getElementById('orderProdCategory').textContent = product.category;
  document.getElementById('orderProdFarmer').textContent = `Sold by: ${product.farmer_name} (${product.farmer_location || 'Local Farm'})`;
  document.getElementById('orderProdPrice').textContent = `₹${Number(product.price).toFixed(2)}`;
  document.getElementById('orderProdUnit').textContent = product.unit;
  document.getElementById('orderProdUnit2').textContent = product.unit;
  document.getElementById('orderProdStock').textContent = product.quantity;
  document.getElementById('orderUnitLabel').textContent = product.unit;
  document.getElementById('stockNotice').textContent = `Maximum orderable stock: ${product.quantity} ${product.unit}`;

  // Default quantity
  const defaultQty = Math.min(5, product.quantity);
  const qtyInput = document.getElementById('orderQuantity');
  qtyInput.value = defaultQty;
  qtyInput.max = product.quantity;
  qtyInput.min = 0.1;

  updateOrderCalculation();
  hideAlert('orderAlert');

  // Open modal
  document.getElementById('orderModal').classList.add('open');
}

function updateOrderCalculation() {
  const product = AppState.selectedProductForOrder;
  if (!product) return;

  const qtyInput = document.getElementById('orderQuantity');
  let qty = parseFloat(qtyInput.value);

  if (isNaN(qty) || qty <= 0) {
    qty = 1;
  }

  // Cap at available stock
  if (qty > product.quantity) {
    qty = product.quantity;
    qtyInput.value = qty;
    showToast(`Quantity adjusted to maximum available stock (${product.quantity} ${product.unit}).`, 'info');
  }

  const unitPrice = Number(product.price);
  const total = qty * unitPrice;

  document.getElementById('calcFormula').textContent = `${qty} ${product.unit} × ₹${unitPrice.toFixed(2)}`;
  document.getElementById('calcTotal').textContent = `₹${total.toFixed(2)}`;
}

async function handleOrderSubmit(e) {
  e.preventDefault();

  const product = AppState.selectedProductForOrder;
  if (!product) return;

  const qty = parseFloat(document.getElementById('orderQuantity').value);
  const notes = document.getElementById('orderNotes').value;

  if (isNaN(qty) || qty <= 0) {
    showAlert('orderAlert', 'Please enter a valid order quantity.', 'error');
    return;
  }

  if (qty > product.quantity) {
    showAlert('orderAlert', `Requested quantity exceeds available stock (${product.quantity} ${product.unit}).`, 'error');
    return;
  }

  const submitBtn = document.getElementById('confirmOrderSubmitBtn');
  submitBtn.disabled = true;
  submitBtn.textContent = 'Processing Order...';

  const res = await apiCall('/api/orders', 'POST', {
    product_id: product.id,
    quantity: qty,
    notes
  });

  submitBtn.disabled = false;
  submitBtn.textContent = 'Confirm & Place Order';

  if (res.success) {
    document.getElementById('orderModal').classList.remove('open');
    showToast(`🎉 Order #${res.data.id} placed successfully!`, 'success');
    
    // Refresh products list to show decreased stock
    fetchMarketplaceProducts();
    loadFeaturedProducts();

    // If buyer, prompt or navigate to orders
    if (AppState.user && AppState.user.role === 'buyer') {
      setTimeout(() => navigateTo('buyer-orders'), 500);
    }
  } else {
    showAlert('orderAlert', res.message || 'Order failed. Please try again.', 'error');
  }
}

// ==========================================================================
// FARMER DASHBOARD WORKFLOW
// ==========================================================================
async function loadFarmerDashboard() {
  if (!AppState.user || AppState.user.role !== 'farmer') return;

  document.getElementById('farmerWelcomeTitle').textContent = `Welcome back, ${AppState.user.name}!`;
  document.getElementById('farmerFarmLocation').textContent = 
    `Farm Location: ${AppState.user.location || 'Rural Agro Belt'} • Contact: ${AppState.user.phone || 'Verified'}`;

  // 1. Fetch farmer's listed products
  const prodRes = await apiCall(`/api/products?farmer_id=${AppState.user.id}`);
  if (prodRes.success) {
    AppState.farmerProducts = prodRes.data;
    renderFarmerProductsTable(prodRes.data);
    document.getElementById('kpiFarmerProducts').textContent = prodRes.data.length;
    document.getElementById('farmerProdCountBadge').textContent = prodRes.data.length;

    // Total units in stock
    const totalStock = prodRes.data.reduce((sum, p) => sum + Number(p.quantity), 0);
    document.getElementById('kpiFarmerStock').textContent = `${totalStock.toFixed(0)} units`;
  }

  // 2. Fetch incoming orders for farmer's produce
  const orderRes = await apiCall('/api/orders/my');
  if (orderRes.success) {
    AppState.farmerOrders = orderRes.data;
    renderFarmerOrdersTable(orderRes.data);
    document.getElementById('farmerOrderCountBadge').textContent = orderRes.data.length;

    const pendingCount = orderRes.data.filter(o => o.status === 'Pending').length;
    document.getElementById('kpiFarmerOrdersPending').textContent = pendingCount;

    const totalRev = orderRes.data
      .filter(o => o.status !== 'Cancelled')
      .reduce((sum, o) => sum + Number(o.total_price), 0);
    document.getElementById('kpiFarmerRevenue').textContent = `₹${totalRev.toFixed(2)}`;
  }
}

function renderFarmerProductsTable(products) {
  const tbody = document.getElementById('farmerProductsTableBody');
  if (!products || products.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" class="text-center py-4">
          <div class="empty-state">
            <p>You have not listed any produce yet.</p>
            <button class="btn btn-primary btn-sm" onclick="openProductModal()">➕ Add Your First Produce</button>
          </div>
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = products.map(p => `
    <tr>
      <td>
        <div class="table-cell-produce">
          <img src="${escapeHtml(p.image_url || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600')}" class="tbl-prod-thumb" alt="">
          <div>
            <span class="tbl-prod-name">${escapeHtml(p.name)}</span>
            <span class="tbl-prod-unit">ID: #${p.id}</span>
          </div>
        </div>
      </td>
      <td><span class="badge badge-outline">${escapeHtml(p.category)}</span></td>
      <td><strong>₹${Number(p.price).toFixed(2)}</strong> / ${escapeHtml(p.unit)}</td>
      <td>
        <span class="${p.quantity <= 0 ? 'stock-out' : (p.quantity < 20 ? 'stock-low' : 'stock-in')}">
          ● ${p.quantity} ${escapeHtml(p.unit)}
        </span>
      </td>
      <td><small class="text-muted">${formatDate(p.created_at)}</small></td>
      <td>
        <div class="tbl-actions">
          <button class="btn btn-xs btn-outline btn-edit-product" data-id="${p.id}" title="Edit Listing">✏️ Edit</button>
          <button class="btn btn-xs btn-ghost btn-delete-product" data-id="${p.id}" title="Delete Listing">🗑️</button>
        </div>
      </td>
    </tr>
  `).join('');
}

function renderFarmerOrdersTable(orders) {
  const tbody = document.getElementById('farmerOrdersTableBody');
  if (!orders || orders.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="text-center py-4">
          <p class="text-muted">No orders received yet. When buyers order your produce, they appear here.</p>
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = orders.map(o => `
    <tr>
      <td><strong class="order-id-label">#ORD-${o.id}</strong><br><small class="text-muted">${formatDate(o.created_at)}</small></td>
      <td>
        <strong>${escapeHtml(o.product_name)}</strong><br>
        <small class="text-muted">Unit: ₹${Number(o.unit_price).toFixed(2)} / ${escapeHtml(o.unit)}</small>
      </td>
      <td>
        <strong>${escapeHtml(o.buyer_name)}</strong><br>
        <small class="text-muted">📞 ${escapeHtml(o.buyer_phone || o.buyer_email || 'N/A')}</small>
        ${o.buyer_location ? `<br><small class="text-muted">📍 ${escapeHtml(o.buyer_location)}</small>` : ''}
      </td>
      <td><strong>${o.quantity} ${escapeHtml(o.unit)}</strong></td>
      <td><strong class="text-primary">₹${Number(o.total_price).toFixed(2)}</strong></td>
      <td>
        <span class="badge badge-status-${o.status.toLowerCase()}">${o.status}</span>
      </td>
      <td>
        <select class="form-select order-status-select" data-id="${o.id}">
          <option value="Pending" ${o.status === 'Pending' ? 'selected' : ''}>Pending</option>
          <option value="Accepted" ${o.status === 'Accepted' ? 'selected' : ''}>Accepted</option>
          <option value="Shipped" ${o.status === 'Shipped' ? 'selected' : ''}>Shipped</option>
          <option value="Delivered" ${o.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
          <option value="Cancelled" ${o.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
        </select>
      </td>
    </tr>
  `).join('');
}

// Add or Edit Product
function openProductModal(productId = null) {
  hideAlert('productAlert');
  const form = document.getElementById('formProduct');
  form.reset();

  if (productId) {
    // Edit mode
    const product = AppState.farmerProducts.find(p => p.id === parseInt(productId, 10));
    if (!product) return;

    document.getElementById('productModalTitle').textContent = 'Edit Agricultural Produce';
    document.getElementById('formProductId').value = product.id;
    document.getElementById('prodName').value = product.name;
    document.getElementById('prodCategory').value = product.category;
    document.getElementById('prodPrice').value = product.price;
    document.getElementById('prodQuantity').value = product.quantity;
    document.getElementById('prodUnit').value = product.unit;
    document.getElementById('prodDescription').value = product.description || '';
    document.getElementById('prodImageUrl').value = product.image_url || '';
  } else {
    // Add mode
    document.getElementById('productModalTitle').textContent = 'Add Agricultural Produce';
    document.getElementById('formProductId').value = '';
    document.getElementById('prodUnit').value = 'kg';
    document.getElementById('prodImageUrl').value = 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600';
  }

  document.getElementById('productModal').classList.add('open');
}

async function handleProductFormSubmit(e) {
  e.preventDefault();

  const id = document.getElementById('formProductId').value;
  const name = document.getElementById('prodName').value.trim();
  const category = document.getElementById('prodCategory').value;
  const price = parseFloat(document.getElementById('prodPrice').value);
  const quantity = parseFloat(document.getElementById('prodQuantity').value);
  const unit = document.getElementById('prodUnit').value;
  const description = document.getElementById('prodDescription').value.trim();
  const image_url = document.getElementById('prodImageUrl').value.trim();

  if (!name || isNaN(price) || isNaN(quantity)) {
    showAlert('productAlert', 'Please enter valid name, price, and stock quantity.', 'error');
    return;
  }

  const payload = { name, category, price, quantity, unit, description, image_url };
  const endpoint = id ? `/api/products/${id}` : '/api/products';
  const method = id ? 'PUT' : 'POST';

  const res = await apiCall(endpoint, method, payload);
  if (res.success) {
    document.getElementById('productModal').classList.remove('open');
    showToast(id ? 'Produce listing updated successfully!' : 'Produce added to marketplace catalog!', 'success');
    loadFarmerDashboard();
    fetchMarketplaceProducts();
  } else {
    showAlert('productAlert', res.message || 'Operation failed.', 'error');
  }
}

async function handleDeleteProduct(productId) {
  if (!confirm('Are you sure you want to delete this produce listing from the marketplace?')) {
    return;
  }

  const res = await apiCall(`/api/products/${productId}`, 'DELETE');
  if (res.success) {
    showToast('Produce listing removed successfully.', 'success');
    loadFarmerDashboard();
    fetchMarketplaceProducts();
  } else {
    alert(res.message || 'Unable to delete listing.');
  }
}

async function handleOrderStatusChange(orderId, newStatus) {
  const res = await apiCall(`/api/orders/${orderId}/status`, 'PATCH', { status: newStatus });
  if (res.success) {
    showToast(`Order #${orderId} marked as ${newStatus}!`, 'success');
    loadFarmerDashboard();
  } else {
    showToast(res.message || 'Failed to update order status.', 'error');
    loadFarmerDashboard(); // reload to reset select
  }
}

// ==========================================================================
// BUYER ORDERS WORKFLOW
// ==========================================================================
async function loadBuyerOrders(statusFilter = 'All') {
  if (!AppState.user || AppState.user.role !== 'buyer') return;

  const container = document.getElementById('buyerOrdersContainer');
  container.innerHTML = `
    <div class="loading-state">
      <div class="spinner"></div>
      <p>Loading your orders...</p>
    </div>
  `;

  const res = await apiCall('/api/orders/my');
  if (res.success) {
    AppState.buyerOrders = res.data;
    
    let displayList = res.data;
    if (statusFilter !== 'All') {
      displayList = displayList.filter(o => o.status === statusFilter);
    }

    renderBuyerOrders(displayList, container);
  } else {
    container.innerHTML = `<div class="empty-state"><p>Failed to load orders.</p></div>`;
  }
}

function renderBuyerOrders(orders, container) {
  if (!orders || orders.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">🛒</div>
        <h3>No orders found</h3>
        <p>You have not placed any orders matching this filter yet.</p>
        <button class="btn btn-primary btn-sm" onclick="navigateTo('marketplace')">Explore Produce Marketplace</button>
      </div>
    `;
    return;
  }

  container.innerHTML = orders.map(o => {
    // Determine progress bar stages
    const statuses = ['Pending', 'Accepted', 'Shipped', 'Delivered'];
    const currentIdx = statuses.indexOf(o.status);
    const isCancelled = o.status === 'Cancelled';

    return `
      <div class="order-card">
        <div class="order-card-header">
          <div class="och-left">
            <span class="order-id-label">#ORD-${o.id}</span>
            <span class="badge badge-status-${o.status.toLowerCase()}">${o.status}</span>
          </div>
          <span class="order-timestamp">Placed: ${formatDate(o.created_at)}</span>
        </div>

        <div class="order-card-body">
          <img src="${escapeHtml(o.product_image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=600')}" class="order-item-img" alt="">
          
          <div class="order-details-col">
            <h4>${escapeHtml(o.product_name)}</h4>
            <div class="order-meta-info">
              <span>👨‍🌾 Farmer: <strong>${escapeHtml(o.farmer_name)}</strong></span>
              ${o.farmer_phone ? `<span>📞 ${escapeHtml(o.farmer_phone)}</span>` : ''}
              ${o.farmer_location ? `<span>📍 ${escapeHtml(o.farmer_location)}</span>` : ''}
            </div>
            ${o.notes ? `<p class="small text-muted mt-2"><em>Notes: "${escapeHtml(o.notes)}"</em></p>` : ''}
          </div>

          <div class="order-price-col">
            <div class="opc-total">₹${Number(o.total_price).toFixed(2)}</div>
            <div class="opc-breakdown">${o.quantity} ${escapeHtml(o.unit)} × ₹${Number(o.unit_price).toFixed(2)}</div>
          </div>
        </div>

        <!-- Progress Tracking -->
        ${!isCancelled ? `
          <div class="order-tracking-bar">
            ${statuses.map((s, idx) => `
              <div class="track-step ${idx <= currentIdx ? 'completed' : ''}">
                <div class="ts-icon">${idx <= currentIdx ? '✓' : (idx + 1)}</div>
                <span class="ts-label">${s}</span>
              </div>
            `).join('')}
          </div>
        ` : `
          <div class="alert-box alert-error" style="margin:0;">
            This order was cancelled. Stock has been restored to the farmer's inventory.
          </div>
        `}
      </div>
    `;
  }).join('');
}

// ==========================================================================
// ADMIN DASHBOARD WORKFLOW
// ==========================================================================
async function loadAdminDashboard() {
  if (!AppState.user || AppState.user.role !== 'admin') return;

  // 1. Stats
  const statsRes = await apiCall('/api/admin/stats');
  if (statsRes.success) {
    const s = statsRes.stats;
    document.getElementById('adminTotalFarmers').textContent = s.totalFarmers;
    document.getElementById('adminTotalBuyers').textContent = s.totalBuyers;
    document.getElementById('adminTotalProducts').textContent = s.totalProducts;
    document.getElementById('adminTotalRevenue').textContent = `₹${Number(s.totalRevenue).toFixed(2)}`;
  }

  // 2. Orders
  const ordersRes = await apiCall('/api/orders/my');
  if (ordersRes.success) {
    const tbody = document.getElementById('adminOrdersTableBody');
    tbody.innerHTML = ordersRes.data.map(o => `
      <tr>
        <td><strong>#ORD-${o.id}</strong></td>
        <td>${escapeHtml(o.product_name)}</td>
        <td>${escapeHtml(o.farmer_name)}</td>
        <td>${escapeHtml(o.buyer_name)}</td>
        <td>${o.quantity} ${escapeHtml(o.unit)}</td>
        <td><strong>₹${Number(o.total_price).toFixed(2)}</strong></td>
        <td><span class="badge badge-status-${o.status.toLowerCase()}">${o.status}</span></td>
        <td><small class="text-muted">${formatDate(o.created_at)}</small></td>
      </tr>
    `).join('');
  }

  // 3. Users
  const usersRes = await apiCall('/api/admin/users');
  if (usersRes.success) {
    const tbody = document.getElementById('adminUsersTableBody');
    tbody.innerHTML = usersRes.users.map(u => `
      <tr>
        <td>#${u.id}</td>
        <td><strong>${escapeHtml(u.name)}</strong></td>
        <td>${escapeHtml(u.email)}</td>
        <td><span class="badge ${u.role === 'farmer' ? 'badge-primary' : (u.role === 'admin' ? 'badge-accent' : 'badge-outline')}">${u.role}</span></td>
        <td>${escapeHtml(u.phone || 'N/A')}</td>
        <td>${escapeHtml(u.location || 'N/A')}</td>
        <td><small class="text-muted">${formatDate(u.created_at)}</small></td>
      </tr>
    `).join('');
  }
}

async function handleAdminSeedReset() {
  if (!confirm('CAUTION: This will reset all users, products, and orders back to initial hackathon demo seed state. Proceed?')) {
    return;
  }

  const res = await apiCall('/api/admin/seed-reset', 'POST', { passkey: 'hackathon-p309' });
  if (res.success) {
    showToast('Database cleanly reset with fresh demo seed data!', 'success');
    loadAdminDashboard();
  } else {
    showToast(res.message || 'Reset failed.', 'error');
  }
}

// ==========================================================================
// AUTHENTICATION MODAL & LOGINS
// ==========================================================================
function openAuthModal(defaultTab = 'login') {
  hideAlert('authAlert');
  const modal = document.getElementById('authModal');
  switchAuthTab(defaultTab);
  modal.classList.add('open');
}

function switchAuthTab(tabName) {
  const tabLogin = document.getElementById('tabLogin');
  const tabRegister = document.getElementById('tabRegister');
  const formLogin = document.getElementById('formLogin');
  const formRegister = document.getElementById('formRegister');

  hideAlert('authAlert');

  if (tabName === 'login') {
    tabLogin.classList.add('active');
    tabRegister.classList.remove('active');
    formLogin.style.display = 'block';
    formRegister.style.display = 'none';
  } else {
    tabRegister.classList.add('active');
    tabLogin.classList.remove('active');
    formRegister.style.display = 'block';
    formLogin.style.display = 'none';
  }
}

async function handleLoginSubmit(e) {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value;

  if (!email || !password) {
    showAlert('authAlert', 'Please enter email and password.', 'error');
    return;
  }

  const btn = document.getElementById('submitLoginBtn');
  btn.disabled = true;
  btn.textContent = 'Logging in...';

  const res = await apiCall('/api/auth/login', 'POST', { email, password });
  btn.disabled = false;
  btn.textContent = 'Log In to FarmDirect';

  if (res.success) {
    AppState.token = res.token;
    AppState.user = res.user;
    localStorage.setItem('farmdirect_token', res.token);
    localStorage.setItem('farmdirect_user', JSON.stringify(res.user));

    updateAuthUI();
    document.getElementById('authModal').classList.remove('open');
    showToast(`Welcome back, ${res.user.name}!`, 'success');

    // Route to appropriate view
    if (res.user.role === 'farmer') navigateTo('farmer-dashboard');
    else if (res.user.role === 'admin') navigateTo('admin-dashboard');
    else navigateTo('marketplace');
  } else {
    showAlert('authAlert', res.message || 'Invalid credentials.', 'error');
  }
}

async function handleRegisterSubmit(e) {
  e.preventDefault();
  const name = document.getElementById('regName').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const password = document.getElementById('regPassword').value;
  const phone = document.getElementById('regPhone').value.trim();
  const location = document.getElementById('regLocation').value.trim();
  
  const roleInput = document.querySelector('input[name="registerRole"]:checked');
  const role = roleInput ? roleInput.value : 'farmer';

  if (!name || !email || !password) {
    showAlert('authAlert', 'Name, email, and password are required.', 'error');
    return;
  }

  const btn = document.getElementById('submitRegisterBtn');
  btn.disabled = true;
  btn.textContent = 'Creating account...';

  const res = await apiCall('/api/auth/register', 'POST', {
    name, email, password, role, phone, location
  });

  btn.disabled = false;
  btn.textContent = 'Create FarmDirect Account';

  if (res.success) {
    AppState.token = res.token;
    AppState.user = res.user;
    localStorage.setItem('farmdirect_token', res.token);
    localStorage.setItem('farmdirect_user', JSON.stringify(res.user));

    updateAuthUI();
    document.getElementById('authModal').classList.remove('open');
    showToast(`Account created! Welcome, ${res.user.name}.`, 'success');

    if (role === 'farmer') navigateTo('farmer-dashboard');
    else navigateTo('marketplace');
  } else {
    showAlert('authAlert', res.message || 'Registration failed.', 'error');
  }
}

// Quick Demo Login
async function executeDemoLogin(roleType) {
  let email, password;
  if (roleType === 'farmer') {
    email = 'ramesh.farmer@farmdirect.com';
    password = 'Farmer@123';
  } else if (roleType === 'buyer') {
    email = 'priya.buyer@farmdirect.com';
    password = 'Buyer@123';
  } else if (roleType === 'admin') {
    email = 'admin@farmdirect.com';
    password = 'Admin@123';
  }

  const res = await apiCall('/api/auth/login', 'POST', { email, password });
  if (res.success) {
    AppState.token = res.token;
    AppState.user = res.user;
    localStorage.setItem('farmdirect_token', res.token);
    localStorage.setItem('farmdirect_user', JSON.stringify(res.user));

    updateAuthUI();
    document.getElementById('authModal').classList.remove('open');
    document.getElementById('demoModal').classList.remove('open');
    showToast(`Logged in as Demo ${roleType.toUpperCase()} (${res.user.name})`, 'success');

    if (roleType === 'farmer') navigateTo('farmer-dashboard');
    else if (roleType === 'admin') navigateTo('admin-dashboard');
    else navigateTo('marketplace');
  } else {
    showToast(`Demo login error: ${res.message}`, 'error');
  }
}

// ==========================================================================
// EVENT LISTENERS INITIALIZATION
// ==========================================================================
function initEventListeners() {
  // Navigation Links
  document.querySelectorAll('[data-view]').forEach(elem => {
    elem.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo(elem.dataset.view);
    });
  });

  // Mobile menu toggle
  document.getElementById('mobileMenuBtn').addEventListener('click', () => {
    document.getElementById('mainNav').classList.toggle('open');
  });

  // Brand Link
  document.getElementById('brandLink').addEventListener('click', (e) => {
    e.preventDefault();
    navigateTo('home');
  });

  // Auth Buttons
  document.getElementById('loginBtn').addEventListener('click', () => openAuthModal('login'));
  document.getElementById('registerBtn').addEventListener('click', () => openAuthModal('register'));
  document.getElementById('logoutBtn').addEventListener('click', () => {
    clearAuth();
    showToast('Logged out successfully.', 'info');
    navigateTo('home');
  });

  // User Profile Chip click
  document.getElementById('userProfileChip').addEventListener('click', () => {
    if (AppState.user) {
      if (AppState.user.role === 'farmer') navigateTo('farmer-dashboard');
      else if (AppState.user.role === 'admin') navigateTo('admin-dashboard');
      else navigateTo('buyer-orders');
    }
  });

  // Quick Demo Buttons
  document.getElementById('quickDemoBtn').addEventListener('click', () => {
    document.getElementById('demoModal').classList.add('open');
  });

  document.querySelectorAll('[data-demo]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      executeDemoLogin(btn.dataset.demo);
    });
  });

  // Hero CTAs
  document.getElementById('heroExploreBtn').addEventListener('click', () => navigateTo('marketplace'));
  document.getElementById('heroFarmerJoinBtn').addEventListener('click', () => openAuthModal('register'));
  document.getElementById('viewAllProduceBtn').addEventListener('click', () => navigateTo('marketplace'));
  document.getElementById('ctaRegisterFarmerBtn').addEventListener('click', () => openAuthModal('register'));
  document.getElementById('ctaBrowseBtn').addEventListener('click', () => navigateTo('marketplace'));

  // Category Cards in Home
  document.querySelectorAll('#homeCategoriesGrid .category-card').forEach(card => {
    card.addEventListener('click', () => {
      AppState.filters.category = card.dataset.category;
      document.querySelectorAll('#categoryPills .cat-pill').forEach(pill => {
        pill.classList.toggle('active', pill.dataset.category === card.dataset.category);
      });
      navigateTo('marketplace');
    });
  });

  // How it works tabs
  document.querySelectorAll('.wf-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.wf-tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const isBuyer = btn.dataset.wf === 'buyer';
      document.getElementById('wfBuyer').style.display = isBuyer ? 'block' : 'none';
      document.getElementById('wfFarmer').style.display = !isBuyer ? 'block' : 'none';
    });
  });

  // Marketplace Search & Filters
  const searchInput = document.getElementById('searchInput');
  const searchClear = document.getElementById('searchClearBtn');
  let searchTimeout;

  searchInput.addEventListener('input', () => {
    searchClear.style.display = searchInput.value ? 'block' : 'none';
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      AppState.filters.search = searchInput.value.trim();
      fetchMarketplaceProducts();
    }, 280);
  });

  searchClear.addEventListener('click', () => {
    searchInput.value = '';
    searchClear.style.display = 'none';
    AppState.filters.search = '';
    fetchMarketplaceProducts();
  });

  // Category Pills in Marketplace
  document.querySelectorAll('#categoryPills .cat-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('#categoryPills .cat-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      AppState.filters.category = pill.dataset.category;
      fetchMarketplaceProducts();
    });
  });

  // Sort & Stock toggle
  document.getElementById('sortSelect').addEventListener('change', (e) => {
    AppState.filters.sort = e.target.value;
    fetchMarketplaceProducts();
  });

  document.getElementById('inStockToggle').addEventListener('change', (e) => {
    AppState.filters.inStock = e.target.checked;
    fetchMarketplaceProducts();
  });

  document.getElementById('refreshProductsBtn').addEventListener('click', fetchMarketplaceProducts);

  // Produce Grid delegate for Order Now clicks
  document.addEventListener('click', (e) => {
    const orderBtn = e.target.closest('.btn-order-produce');
    if (orderBtn) {
      openOrderModal(orderBtn.dataset.id);
    }
  });

  // Order Modal interactions
  const qtyInput = document.getElementById('orderQuantity');
  qtyInput.addEventListener('input', updateOrderCalculation);

  document.getElementById('qtyMinusBtn').addEventListener('click', () => {
    const val = parseFloat(qtyInput.value) || 1;
    if (val > 1) {
      qtyInput.value = val - 1;
      updateOrderCalculation();
    }
  });

  document.getElementById('qtyPlusBtn').addEventListener('click', () => {
    const val = parseFloat(qtyInput.value) || 0;
    qtyInput.value = val + 1;
    updateOrderCalculation();
  });

  document.getElementById('formPlaceOrder').addEventListener('submit', handleOrderSubmit);
  document.getElementById('cancelOrderBtn').addEventListener('click', () => {
    document.getElementById('orderModal').classList.remove('open');
  });
  document.getElementById('closeOrderModal').addEventListener('click', () => {
    document.getElementById('orderModal').classList.remove('open');
  });

  // Farmer Dashboard Tabs
  document.querySelectorAll('.dash-tabs .dash-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const parent = btn.parentElement;
      parent.querySelectorAll('.dash-tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const targetTab = btn.dataset.tab;
      if (targetTab === 'farmer-products') {
        document.getElementById('tabFarmerProducts').style.display = 'block';
        document.getElementById('tabFarmerOrders').style.display = 'none';
      } else if (targetTab === 'farmer-orders') {
        document.getElementById('tabFarmerProducts').style.display = 'none';
        document.getElementById('tabFarmerOrders').style.display = 'block';
      } else if (targetTab === 'admin-orders') {
        document.getElementById('tabAdminOrders').style.display = 'block';
        document.getElementById('tabAdminUsers').style.display = 'none';
      } else if (targetTab === 'admin-users') {
        document.getElementById('tabAdminOrders').style.display = 'none';
        document.getElementById('tabAdminUsers').style.display = 'block';
      }
    });
  });

  // Add Product Modal button
  document.getElementById('openAddProductModalBtn').addEventListener('click', () => openProductModal());
  document.getElementById('formProduct').addEventListener('submit', handleProductFormSubmit);
  document.getElementById('cancelProductBtn').addEventListener('click', () => {
    document.getElementById('productModal').classList.remove('open');
  });
  document.getElementById('closeProductModal').addEventListener('click', () => {
    document.getElementById('productModal').classList.remove('open');
  });

  // Preset chips in product modal
  document.querySelectorAll('.preset-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      document.getElementById('prodImageUrl').value = chip.dataset.img;
    });
  });

  // Delegate for edit and delete product buttons in farmer table
  document.getElementById('farmerProductsTableBody').addEventListener('click', (e) => {
    const editBtn = e.target.closest('.btn-edit-product');
    if (editBtn) openProductModal(editBtn.dataset.id);

    const deleteBtn = e.target.closest('.btn-delete-product');
    if (deleteBtn) handleDeleteProduct(deleteBtn.dataset.id);
  });

  // Delegate for order status updates in farmer table
  document.getElementById('farmerOrdersTableBody').addEventListener('change', (e) => {
    if (e.target.classList.contains('order-status-select')) {
      handleOrderStatusChange(e.target.dataset.id, e.target.value);
    }
  });

  // Buyer Orders Filter Pills
  document.querySelectorAll('#buyerOrderFilterPills .order-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('#buyerOrderFilterPills .order-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      loadBuyerOrders(pill.dataset.status);
    });
  });
  document.getElementById('refreshBuyerOrdersBtn').addEventListener('click', () => loadBuyerOrders());

  // Admin Seed Reset
  document.getElementById('adminSeedResetBtn').addEventListener('click', handleAdminSeedReset);

  // Auth Form submissions & Modal tabs
  document.getElementById('tabLogin').addEventListener('click', () => switchAuthTab('login'));
  document.getElementById('tabRegister').addEventListener('click', () => switchAuthTab('register'));
  document.getElementById('formLogin').addEventListener('submit', handleLoginSubmit);
  document.getElementById('formRegister').addEventListener('submit', handleRegisterSubmit);
  document.getElementById('closeAuthModal').addEventListener('click', () => {
    document.getElementById('authModal').classList.remove('open');
  });
  document.getElementById('closeDemoModal').addEventListener('click', () => {
    document.getElementById('demoModal').classList.remove('open');
  });

  // Close modals on backdrop click or ESC
  document.querySelectorAll('.modal-backdrop').forEach(modal => {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.classList.remove('open');
    });
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal-backdrop.open').forEach(m => m.classList.remove('open'));
    }
  });
}

// ==========================================================================
// UI HELPERS & NOTIFICATIONS
// ==========================================================================
function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;

  const icon = type === 'success' ? '✅' : (type === 'error' ? '⚠️' : 'ℹ️');
  toast.innerHTML = `<span>${icon}</span><span>${escapeHtml(message)}</span>`;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(8px)';
    toast.style.transition = 'all 0.25s ease';
    setTimeout(() => toast.remove(), 250);
  }, 4000);
}

function showAlert(elementId, message, type = 'error') {
  const el = document.getElementById(elementId);
  if (!el) return;
  el.className = `alert-box alert-${type}`;
  el.textContent = message;
  el.style.display = 'block';
}

function hideAlert(elementId) {
  const el = document.getElementById(elementId);
  if (el) el.style.display = 'none';
}

function resetFilters() {
  AppState.filters.category = 'All';
  AppState.filters.search = '';
  document.getElementById('searchInput').value = '';
  document.querySelectorAll('#categoryPills .cat-pill').forEach(p => {
    p.classList.toggle('active', p.dataset.category === 'All');
  });
  fetchMarketplaceProducts();
}

function formatDate(dateString) {
  if (!dateString) return '';
  const date = new Date(dateString);
  return date.toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

function escapeHtml(str) {
  if (typeof str !== 'string') return str;
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

