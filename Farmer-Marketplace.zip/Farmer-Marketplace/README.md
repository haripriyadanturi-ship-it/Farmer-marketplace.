# 🌾 FarmDirect — Direct Agricultural Marketplace
> **College Hackathon Prototype for Backend Web Development**  
> **Problem Statement ID:** `HACK-P309`  
> **Tagline:** *Fresh from farms, directly to you.*  
> **Live Local URL:** `http://localhost:3000`

[![Node.js](https://img.shields.io/badge/Node.js-v20%2B-339933?logo=node.js&logoColor=white)](https://nodejs.org/)
[![Express.js](https://img.shields.io/badge/Express.js-5.x-000000?logo=express&logoColor=white)](https://expressjs.com/)
[![SQLite](https://img.shields.io/badge/SQLite-WAL%20Mode-003B57?logo=sqlite&logoColor=white)](https://www.sqlite.org/)
[![JWT](https://img.shields.io/badge/Auth-JWT%20%2B%20bcrypt-000000?logo=jsonwebtokens&logoColor=white)](https://jwt.io/)
[![Tests](https://img.shields.io/badge/Automated%20Tests-32%2F32%20Passed%20(100%25)-brightgreen)](tests/test-api.js)

---

## 📌 Project Overview
**FarmDirect** is a digital agricultural marketplace that connects rural farmers directly with urban consumers and commercial buyers. Traditional agricultural distribution networks in developing regions force farmers through 3 to 5 layers of commission agents, brokers, and wholesale middlemen, drastically cutting farmer earnings while inflating consumer prices.

FarmDirect eliminates intermediaries, giving farmers 100% of their sales proceeds, full pricing autonomy, and real-time order visibility, while consumers enjoy freshly harvested produce at transparent, fair rates.

---

## ✨ Key Features

### 👨‍🌾 For Farmers
- **Produce Management:** Publish, edit, and manage crop listings with prices, stock levels, units (`kg`, `quintal`, `dozen`, `litre`, `bunch`), and photos.
- **Real-Time Inventory Control:** Available stock automatically updates with every incoming order.
- **Order Fulfillment Console:** View incoming orders with buyer contacts and delivery notes; update order status across 4 lifecycle stages: `Pending` ➔ `Accepted` ➔ `Shipped` ➔ `Delivered`.
- **Ownership Security:** Backend authorization ensures farmers can only modify or delete products and orders belonging to their own farm.

### 🛒 For Buyers
- **Live Produce Catalog:** Search produce by name (`Tomatoes`, `Basmati Rice`, `Shimla Apples`) and filter by category (`Vegetables`, `Fruits`, `Grains & Cereals`, `Dairy & Eggs`, `Herbs & Spices`).
- **Dynamic Cost Calculator:** Interactive order modal calculates the total cost instantly based on requested quantity.
- **Stock Guard Protection:** Orders exceeding current inventory are rejected with clear error feedback.
- **Live Order Tracking:** Track deliveries in real time with a 4-stage visual progress tracker.

### 🛡️ For Administrators
- **Platform Analytics:** Real-time Gross Merchandise Value (GMV), total farmers, buyers, listings, and order breakdowns.
- **Demo Seed Reset:** A one-click reset endpoint to refresh demo data cleanly during hackathon evaluations.

---

## 🛠️ Technology Stack

| Layer | Component | Description |
|---|---|---|
| **Frontend** | HTML5, CSS3, Vanilla JavaScript (ES6+) | Ultra-fast Single Page Application (SPA), zero external UI frameworks, responsive flex/grid layouts. |
| **Backend** | Node.js & Express.js (v5) | Modular RESTful API architecture with centralized error handling and request logging. |
| **Database** | SQLite (via `better-sqlite3`) | Embedded relational database with `PRAGMA journal_mode=WAL;` and foreign keys enforced. |
| **Security** | `bcryptjs` & `jsonwebtoken` | Salted password hashing (10 rounds) and 7-day signed JWT Bearer authentication. |
| **Testing** | Custom In-Memory Test Suite & Postman | 32 automated tests verifying business logic, transactions, and security permissions. |
| **VCS** | Git & GitHub | Clean repository structure with `.gitignore` and `.env.example`. |

---

## 📂 Project Directory Structure

```
farmer-marketplace/
├── database/
│   ├── db.js                     # SQLite initialization, schema creation & WAL mode
│   └── seed.js                   # Demo data seeder (farmers, buyers, crops, orders)
├── docs/
│   ├── api-documentation.md       # Comprehensive REST API specifications
│   ├── database-design.md        # Database schema, ER diagram & transaction rules
│   ├── demo-video-script.md      # Timed 2-3 minute video demonstration script
│   ├── postman-collection.json   # Ready-to-import Postman v2.1 test collection
│   ├── project-documentation.md  # 19-section full hackathon technical report
│   └── team-contribution.md      # Detailed 4-member task division & defense talking points
├── middleware/
│   └── authMiddleware.js         # JWT authentication & Role-Based Access Control (RBAC)
├── public/
│   ├── app.js                    # Client-side SPA routing, API integration & DOM logic
│   ├── index.html                # Semantic HTML5 frontend with all dashboards & modals
│   └── style.css                 # Green, earthy, responsive design stylesheet
├── routes/
│   ├── admin.js                  # Analytics, platform oversight & demo reset APIs
│   ├── auth.js                   # Register, login & profile retrieval endpoints
│   ├── orders.js                 # Transactional order placement & status updates
│   └── products.js               # Produce CRUD, search & category filtering
├── tests/
│   ├── run-all.js                # Test runner helper
│   └── test-api.js               # In-memory automated test suite (32 test cases)
├── .env.example                  # Template for environment configuration
├── .gitignore                    # Excludes node_modules, .env, and local database binaries
├── package.json                  # Dependencies, metadata & run scripts
├── README.md                     # Project overview and execution guide
└── server.js                     # Main Express server entry point
```

---

## ⚡ Quick Start & Installation

### Prerequisites
- **Node.js**: v18.x, v20.x, or v22+ installed ([Download Node.js](https://nodejs.org/))
- **npm**: v9.x or higher

### Step 1: Clone or Open the Workspace
```bash
git clone <your-repository-url>
cd farmer-marketplace
```

### Step 2: Install Dependencies
```bash
npm install
```

### Step 3: Configure Environment Variables
Copy the example environment file:
```bash
# On Windows PowerShell:
Copy-Item .env.example .env

# On Linux / macOS:
cp .env.example .env
```
*(The default settings in `.env.example` run out of the box with zero modifications required).*

### Step 4: Run the Application
```bash
npm start
```
The server will automatically initialize the SQLite database (`database/farmer_marketplace.db`) and seed demo records.

Open your browser and navigate to:  
👉 **`http://localhost:3000`**

---

## 🔑 Pre-Seeded Demo Accounts (Instant Hackathon Testing)

The application includes a **"⚡ Quick Demo Logins"** button in the top navigation bar for one-click access:

| Role | Name | Email Address | Password | Permissions |
|---|---|---|---|---|
| **Farmer** | Ramesh Patel | `ramesh.farmer@farmdirect.com` | `Farmer@123` | List crops, update prices, manage stock, accept/ship orders |
| **Farmer** | Sunita Sharma | `sunita.farmer@farmdirect.com` | `Farmer@123` | Manage organic basmati rice and spices |
| **Buyer** | Priya Verma | `priya.buyer@farmdirect.com` | `Buyer@123` | Browse catalog, calculate total, place orders, track shipments |
| **Buyer** | Amit Sen | `amit.buyer@farmdirect.com` | `Buyer@123` | Browse catalog, order produce, view historical purchases |
| **Admin** | System Admin | `admin@farmdirect.com` | `Admin@123` | View all orders, inspect platform users, reset demo data |

---

## 🧪 Automated Testing

FarmDirect comes with an integrated automated test suite covering all 32 critical business, transactional, and security scenarios.

Run the test suite using:
```bash
npm test
```

### Test Coverage Highlights:
- ✅ Health check & SQLite database connectivity.
- ✅ New user registration with input validation.
- ✅ Duplicate email rejection (`HTTP 409 Conflict`).
- ✅ Password authentication (`HTTP 401` on invalid credentials).
- ✅ Product discovery, keyword search (`?q=`), and category filter (`?category=`).
- ✅ Role authorization: buyers are forbidden from creating produce listings (`HTTP 403`).
- ✅ Farmer ownership guard: farmers cannot edit or delete crops from other farms.
- ✅ **ACID Transaction:** Atomic stock deduction and backend price calculation.
- ✅ Insufficient stock rejection (`HTTP 400 Bad Request` when ordering > stock).
- ✅ Order status update workflow (`Pending` ➔ `Accepted` ➔ `Shipped`).
- ✅ Stock restoration: cancelling an order automatically returns items to stock.
- ✅ Audit preservation: products with active orders cannot be hard-deleted.

---

## 📬 Postman API Collection
An exportable Postman Collection v2.1 is located at:  
👉 `docs/postman-collection.json`

### To Import into Postman:
1. Open **Postman**.
2. Click **Import** (top left).
3. Select `docs/postman-collection.json`.
4. Run requests in sequence—tokens for Farmer, Buyer, and Admin are saved into collection variables automatically upon login!

---

## 👥 Four-Member Team Contribution & Responsibilities

| Student | Assigned Role | Key Deliverables & Code Ownership |
|---|---|---|
| **Member 1** | Frontend Design & UX Specialist | Authored `public/index.html`, `public/style.css`, and SPA routing & responsive layouts in `public/app.js`. |
| **Member 2** | Backend & Security Engineer | Authored `server.js`, `routes/auth.js`, and JWT/RBAC middleware in `middleware/authMiddleware.js`. |
| **Member 3** | Database Architect & API Dev | Authored `database/db.js`, `database/seed.js`, `routes/products.js`, and transactional `routes/orders.js`. |
| **Member 4** | QA, Integration & Documentation Lead | Authored `tests/test-api.js`, `docs/postman-collection.json`, demo video script, and technical reports. |

*(For full details and viva defense questions, refer to `docs/team-contribution.md`).*

---

## 🚀 Git Commands for Repository Upload

To publish this codebase to your team's GitHub repository:

```bash
# 1. Initialize git repository (if not already initialized)
git init

# 2. Add all files (respecting .gitignore)
git add .

# 3. Create the initial commit
git commit -m "feat: complete functional prototype for Farmer Marketplace (HACK-P309)"

# 4. Set main branch
git branch -M main

# 5. Link your GitHub repository remote
git remote add origin https://github.com/<your-team-username>/farmer-marketplace.git

# 6. Push code to GitHub
git push -u origin main
```

---

## 🏆 Hackathon Evaluation Summary
- **Problem Statement ID:** HACK-P309
- **Working Prototype:** 100% functional, local execution with SQLite persistence.
- **Demonstration Script:** Detailed 2.5-minute video guide located in `docs/demo-video-script.md`.
- **Source Code Quality:** Clean, modular structure without unnecessary frameworks or external bloat.
- **Academic Integrity:** Built by a team of 4 students with documented contributions.

